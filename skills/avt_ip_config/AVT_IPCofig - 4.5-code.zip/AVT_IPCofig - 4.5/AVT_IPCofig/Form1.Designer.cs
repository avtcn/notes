﻿namespace AVT_IPCofig
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tB_Log = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.group_netInfo = new System.Windows.Forms.GroupBox();
            this.bT_OpenConnections = new System.Windows.Forms.Button();
            this.tb_NiMTU = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_setNicIP = new System.Windows.Forms.Button();
            this.tb_NiDiscrip = new System.Windows.Forms.TextBox();
            this.label_netDiscript = new System.Windows.Forms.Label();
            this.cb_NiIpmode = new System.Windows.Forms.ComboBox();
            this.tb_Nigateway = new System.Windows.Forms.TextBox();
            this.tb_NiIpmarsk = new System.Windows.Forms.TextBox();
            this.tb_NiIpaddr = new System.Windows.Forms.TextBox();
            this.label_netGateway = new System.Windows.Forms.Label();
            this.label_netIpmarsk = new System.Windows.Forms.Label();
            this.label_netIpaddr = new System.Windows.Forms.Label();
            this.label_netIpmode = new System.Windows.Forms.Label();
            this.group_camInfo = new System.Windows.Forms.GroupBox();
            this.bt_SaveCamIP = new System.Windows.Forms.Button();
            this.tb_CamDiscrip = new System.Windows.Forms.TextBox();
            this.label_camDiscript = new System.Windows.Forms.Label();
            this.tb_camCurIP = new System.Windows.Forms.TextBox();
            this.cb_camConfigMode = new System.Windows.Forms.ComboBox();
            this.label_camGateway = new System.Windows.Forms.Label();
            this.label_camIpaddr = new System.Windows.Forms.Label();
            this.tb_camCurIPMarsk = new System.Windows.Forms.TextBox();
            this.label_camIpmode = new System.Windows.Forms.Label();
            this.label_camIpmarsk = new System.Windows.Forms.Label();
            this.bt_referIP = new System.Windows.Forms.Button();
            this.tb_camCurgateway = new System.Windows.Forms.TextBox();
            this.gB_Connections = new System.Windows.Forms.GroupBox();
            this.bT_RefreshList = new System.Windows.Forms.Button();
            this.cB_ChoseLanguage = new System.Windows.Forms.ComboBox();
            this.label_choseLanguage = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1.SuspendLayout();
            this.group_netInfo.SuspendLayout();
            this.group_camInfo.SuspendLayout();
            this.gB_Connections.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(6, 18);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(243, 301);
            this.treeView1.TabIndex = 0;
            this.treeView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseDown);
            // 
            // tB_Log
            // 
            this.tB_Log.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tB_Log.Location = new System.Drawing.Point(6, 16);
            this.tB_Log.Multiline = true;
            this.tB_Log.Name = "tB_Log";
            this.tB_Log.ReadOnly = true;
            this.tB_Log.Size = new System.Drawing.Size(243, 119);
            this.tB_Log.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tB_Log);
            this.groupBox1.Location = new System.Drawing.Point(3, 360);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(255, 141);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // group_netInfo
            // 
            this.group_netInfo.Controls.Add(this.bT_OpenConnections);
            this.group_netInfo.Controls.Add(this.tb_NiMTU);
            this.group_netInfo.Controls.Add(this.label1);
            this.group_netInfo.Controls.Add(this.bt_setNicIP);
            this.group_netInfo.Controls.Add(this.tb_NiDiscrip);
            this.group_netInfo.Controls.Add(this.label_netDiscript);
            this.group_netInfo.Controls.Add(this.cb_NiIpmode);
            this.group_netInfo.Controls.Add(this.tb_Nigateway);
            this.group_netInfo.Controls.Add(this.tb_NiIpmarsk);
            this.group_netInfo.Controls.Add(this.tb_NiIpaddr);
            this.group_netInfo.Controls.Add(this.label_netGateway);
            this.group_netInfo.Controls.Add(this.label_netIpmarsk);
            this.group_netInfo.Controls.Add(this.label_netIpaddr);
            this.group_netInfo.Controls.Add(this.label_netIpmode);
            this.group_netInfo.Enabled = false;
            this.group_netInfo.Location = new System.Drawing.Point(264, 27);
            this.group_netInfo.Name = "group_netInfo";
            this.group_netInfo.Size = new System.Drawing.Size(356, 234);
            this.group_netInfo.TabIndex = 5;
            this.group_netInfo.TabStop = false;
            this.group_netInfo.Text = "网口";
            // 
            // bT_OpenConnections
            // 
            this.bT_OpenConnections.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bT_OpenConnections.Location = new System.Drawing.Point(271, 87);
            this.bT_OpenConnections.Name = "bT_OpenConnections";
            this.bT_OpenConnections.Size = new System.Drawing.Size(63, 42);
            this.bT_OpenConnections.TabIndex = 15;
            this.bT_OpenConnections.Text = "打开本地网络设置";
            this.bT_OpenConnections.UseVisualStyleBackColor = false;
            this.bT_OpenConnections.Click += new System.EventHandler(this.bT_OpenConnections_Click);
            // 
            // tb_NiMTU
            // 
            this.tb_NiMTU.Location = new System.Drawing.Point(132, 183);
            this.tb_NiMTU.Name = "tb_NiMTU";
            this.tb_NiMTU.ReadOnly = true;
            this.tb_NiMTU.Size = new System.Drawing.Size(100, 20);
            this.tb_NiMTU.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "MTU：";
            // 
            // bt_setNicIP
            // 
            this.bt_setNicIP.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bt_setNicIP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt_setNicIP.Location = new System.Drawing.Point(271, 170);
            this.bt_setNicIP.Name = "bt_setNicIP";
            this.bt_setNicIP.Size = new System.Drawing.Size(63, 45);
            this.bt_setNicIP.TabIndex = 12;
            this.bt_setNicIP.Text = "保存";
            this.bt_setNicIP.UseVisualStyleBackColor = false;
            this.bt_setNicIP.Click += new System.EventHandler(this.bt_setNicIP_Click);
            // 
            // tb_NiDiscrip
            // 
            this.tb_NiDiscrip.Location = new System.Drawing.Point(132, 37);
            this.tb_NiDiscrip.Name = "tb_NiDiscrip";
            this.tb_NiDiscrip.ReadOnly = true;
            this.tb_NiDiscrip.Size = new System.Drawing.Size(202, 20);
            this.tb_NiDiscrip.TabIndex = 11;
            // 
            // label_netDiscript
            // 
            this.label_netDiscript.AutoSize = true;
            this.label_netDiscript.Location = new System.Drawing.Point(54, 40);
            this.label_netDiscript.Name = "label_netDiscript";
            this.label_netDiscript.Size = new System.Drawing.Size(67, 13);
            this.label_netDiscript.TabIndex = 10;
            this.label_netDiscript.Text = "描述信息：";
            // 
            // cb_NiIpmode
            // 
            this.cb_NiIpmode.BackColor = System.Drawing.SystemColors.Window;
            this.cb_NiIpmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_NiIpmode.FormattingEnabled = true;
            this.cb_NiIpmode.Items.AddRange(new object[] {
            "Persistent",
            "DHCP"});
            this.cb_NiIpmode.Location = new System.Drawing.Point(132, 66);
            this.cb_NiIpmode.Name = "cb_NiIpmode";
            this.cb_NiIpmode.Size = new System.Drawing.Size(100, 21);
            this.cb_NiIpmode.TabIndex = 9;
            // 
            // tb_Nigateway
            // 
            this.tb_Nigateway.Location = new System.Drawing.Point(132, 154);
            this.tb_Nigateway.Name = "tb_Nigateway";
            this.tb_Nigateway.ReadOnly = true;
            this.tb_Nigateway.Size = new System.Drawing.Size(100, 20);
            this.tb_Nigateway.TabIndex = 6;
            this.tb_Nigateway.Text = "0.0.0.0";
            // 
            // tb_NiIpmarsk
            // 
            this.tb_NiIpmarsk.Location = new System.Drawing.Point(132, 125);
            this.tb_NiIpmarsk.Name = "tb_NiIpmarsk";
            this.tb_NiIpmarsk.Size = new System.Drawing.Size(100, 20);
            this.tb_NiIpmarsk.TabIndex = 5;
            // 
            // tb_NiIpaddr
            // 
            this.tb_NiIpaddr.Location = new System.Drawing.Point(132, 96);
            this.tb_NiIpaddr.Name = "tb_NiIpaddr";
            this.tb_NiIpaddr.Size = new System.Drawing.Size(100, 20);
            this.tb_NiIpaddr.TabIndex = 4;
            // 
            // label_netGateway
            // 
            this.label_netGateway.AutoSize = true;
            this.label_netGateway.Location = new System.Drawing.Point(54, 156);
            this.label_netGateway.Name = "label_netGateway";
            this.label_netGateway.Size = new System.Drawing.Size(67, 13);
            this.label_netGateway.TabIndex = 3;
            this.label_netGateway.Text = "默认网关：";
            // 
            // label_netIpmarsk
            // 
            this.label_netIpmarsk.AutoSize = true;
            this.label_netIpmarsk.Location = new System.Drawing.Point(54, 127);
            this.label_netIpmarsk.Name = "label_netIpmarsk";
            this.label_netIpmarsk.Size = new System.Drawing.Size(67, 13);
            this.label_netIpmarsk.TabIndex = 2;
            this.label_netIpmarsk.Text = "子网掩码：";
            // 
            // label_netIpaddr
            // 
            this.label_netIpaddr.AutoSize = true;
            this.label_netIpaddr.Location = new System.Drawing.Point(54, 98);
            this.label_netIpaddr.Name = "label_netIpaddr";
            this.label_netIpaddr.Size = new System.Drawing.Size(53, 13);
            this.label_netIpaddr.TabIndex = 1;
            this.label_netIpaddr.Text = "IP地址：";
            // 
            // label_netIpmode
            // 
            this.label_netIpmode.AutoSize = true;
            this.label_netIpmode.Location = new System.Drawing.Point(54, 69);
            this.label_netIpmode.Name = "label_netIpmode";
            this.label_netIpmode.Size = new System.Drawing.Size(77, 13);
            this.label_netIpmode.TabIndex = 0;
            this.label_netIpmode.Text = "IP获取方式：";
            // 
            // group_camInfo
            // 
            this.group_camInfo.Controls.Add(this.bt_SaveCamIP);
            this.group_camInfo.Controls.Add(this.tb_CamDiscrip);
            this.group_camInfo.Controls.Add(this.label_camDiscript);
            this.group_camInfo.Controls.Add(this.tb_camCurIP);
            this.group_camInfo.Controls.Add(this.cb_camConfigMode);
            this.group_camInfo.Controls.Add(this.label_camGateway);
            this.group_camInfo.Controls.Add(this.label_camIpaddr);
            this.group_camInfo.Controls.Add(this.tb_camCurIPMarsk);
            this.group_camInfo.Controls.Add(this.label_camIpmode);
            this.group_camInfo.Controls.Add(this.label_camIpmarsk);
            this.group_camInfo.Controls.Add(this.bt_referIP);
            this.group_camInfo.Controls.Add(this.tb_camCurgateway);
            this.group_camInfo.Enabled = false;
            this.group_camInfo.Location = new System.Drawing.Point(264, 266);
            this.group_camInfo.Name = "group_camInfo";
            this.group_camInfo.Size = new System.Drawing.Size(356, 235);
            this.group_camInfo.TabIndex = 6;
            this.group_camInfo.TabStop = false;
            this.group_camInfo.Text = "相机";
            // 
            // bt_SaveCamIP
            // 
            this.bt_SaveCamIP.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bt_SaveCamIP.Location = new System.Drawing.Point(271, 160);
            this.bt_SaveCamIP.Name = "bt_SaveCamIP";
            this.bt_SaveCamIP.Size = new System.Drawing.Size(63, 44);
            this.bt_SaveCamIP.TabIndex = 11;
            this.bt_SaveCamIP.Text = "保存";
            this.bt_SaveCamIP.UseVisualStyleBackColor = false;
            this.bt_SaveCamIP.Click += new System.EventHandler(this.bt_SaveCamIP_Click);
            // 
            // tb_CamDiscrip
            // 
            this.tb_CamDiscrip.Location = new System.Drawing.Point(132, 29);
            this.tb_CamDiscrip.Name = "tb_CamDiscrip";
            this.tb_CamDiscrip.ReadOnly = true;
            this.tb_CamDiscrip.Size = new System.Drawing.Size(202, 20);
            this.tb_CamDiscrip.TabIndex = 13;
            // 
            // label_camDiscript
            // 
            this.label_camDiscript.AutoSize = true;
            this.label_camDiscript.Location = new System.Drawing.Point(54, 32);
            this.label_camDiscript.Name = "label_camDiscript";
            this.label_camDiscript.Size = new System.Drawing.Size(67, 13);
            this.label_camDiscript.TabIndex = 12;
            this.label_camDiscript.Text = "描述信息：";
            // 
            // tb_camCurIP
            // 
            this.tb_camCurIP.Location = new System.Drawing.Point(132, 85);
            this.tb_camCurIP.Name = "tb_camCurIP";
            this.tb_camCurIP.Size = new System.Drawing.Size(100, 20);
            this.tb_camCurIP.TabIndex = 4;
            // 
            // cb_camConfigMode
            // 
            this.cb_camConfigMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_camConfigMode.FormattingEnabled = true;
            this.cb_camConfigMode.Items.AddRange(new object[] {
            "Persistent",
            "DHCP"});
            this.cb_camConfigMode.Location = new System.Drawing.Point(132, 58);
            this.cb_camConfigMode.Name = "cb_camConfigMode";
            this.cb_camConfigMode.Size = new System.Drawing.Size(100, 21);
            this.cb_camConfigMode.TabIndex = 8;
            // 
            // label_camGateway
            // 
            this.label_camGateway.AutoSize = true;
            this.label_camGateway.Location = new System.Drawing.Point(54, 146);
            this.label_camGateway.Name = "label_camGateway";
            this.label_camGateway.Size = new System.Drawing.Size(67, 13);
            this.label_camGateway.TabIndex = 3;
            this.label_camGateway.Text = "默认网关：";
            // 
            // label_camIpaddr
            // 
            this.label_camIpaddr.AutoSize = true;
            this.label_camIpaddr.Location = new System.Drawing.Point(54, 88);
            this.label_camIpaddr.Name = "label_camIpaddr";
            this.label_camIpaddr.Size = new System.Drawing.Size(53, 13);
            this.label_camIpaddr.TabIndex = 1;
            this.label_camIpaddr.Text = "IP地址：";
            // 
            // tb_camCurIPMarsk
            // 
            this.tb_camCurIPMarsk.Location = new System.Drawing.Point(132, 114);
            this.tb_camCurIPMarsk.Name = "tb_camCurIPMarsk";
            this.tb_camCurIPMarsk.Size = new System.Drawing.Size(100, 20);
            this.tb_camCurIPMarsk.TabIndex = 5;
            // 
            // label_camIpmode
            // 
            this.label_camIpmode.AutoSize = true;
            this.label_camIpmode.Location = new System.Drawing.Point(54, 59);
            this.label_camIpmode.Name = "label_camIpmode";
            this.label_camIpmode.Size = new System.Drawing.Size(77, 13);
            this.label_camIpmode.TabIndex = 0;
            this.label_camIpmode.Text = "IP获取方式：";
            // 
            // label_camIpmarsk
            // 
            this.label_camIpmarsk.AutoSize = true;
            this.label_camIpmarsk.Location = new System.Drawing.Point(54, 117);
            this.label_camIpmarsk.Name = "label_camIpmarsk";
            this.label_camIpmarsk.Size = new System.Drawing.Size(67, 13);
            this.label_camIpmarsk.TabIndex = 2;
            this.label_camIpmarsk.Text = "子网掩码：";
            // 
            // bt_referIP
            // 
            this.bt_referIP.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bt_referIP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt_referIP.Location = new System.Drawing.Point(132, 181);
            this.bt_referIP.Name = "bt_referIP";
            this.bt_referIP.Size = new System.Drawing.Size(100, 23);
            this.bt_referIP.TabIndex = 8;
            this.bt_referIP.Text = "参考设置";
            this.bt_referIP.UseVisualStyleBackColor = false;
            this.bt_referIP.Click += new System.EventHandler(this.bt_AutoModify_Click);
            // 
            // tb_camCurgateway
            // 
            this.tb_camCurgateway.Location = new System.Drawing.Point(132, 143);
            this.tb_camCurgateway.Name = "tb_camCurgateway";
            this.tb_camCurgateway.ReadOnly = true;
            this.tb_camCurgateway.Size = new System.Drawing.Size(100, 20);
            this.tb_camCurgateway.TabIndex = 6;
            this.tb_camCurgateway.Text = "0.0.0.0";
            // 
            // gB_Connections
            // 
            this.gB_Connections.Controls.Add(this.bT_RefreshList);
            this.gB_Connections.Controls.Add(this.treeView1);
            this.gB_Connections.Location = new System.Drawing.Point(3, 6);
            this.gB_Connections.Name = "gB_Connections";
            this.gB_Connections.Size = new System.Drawing.Size(255, 348);
            this.gB_Connections.TabIndex = 12;
            this.gB_Connections.TabStop = false;
            this.gB_Connections.Text = "网络连接";
            // 
            // bT_RefreshList
            // 
            this.bT_RefreshList.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bT_RefreshList.Location = new System.Drawing.Point(173, 321);
            this.bT_RefreshList.Name = "bT_RefreshList";
            this.bT_RefreshList.Size = new System.Drawing.Size(77, 23);
            this.bT_RefreshList.TabIndex = 14;
            this.bT_RefreshList.Text = "手动刷新";
            this.bT_RefreshList.UseVisualStyleBackColor = false;
            this.bT_RefreshList.Click += new System.EventHandler(this.bT_RefreshList_Click);
            // 
            // cB_ChoseLanguage
            // 
            this.cB_ChoseLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cB_ChoseLanguage.FormattingEnabled = true;
            this.cB_ChoseLanguage.Items.AddRange(new object[] {
            "简体中文",
            "English"});
            this.cB_ChoseLanguage.Location = new System.Drawing.Point(445, 4);
            this.cB_ChoseLanguage.Name = "cB_ChoseLanguage";
            this.cB_ChoseLanguage.Size = new System.Drawing.Size(98, 21);
            this.cB_ChoseLanguage.TabIndex = 13;
            this.cB_ChoseLanguage.SelectedIndexChanged += new System.EventHandler(this.cB_ChoseLanguage_SelectedIndexChanged);
            // 
            // label_choseLanguage
            // 
            this.label_choseLanguage.AutoSize = true;
            this.label_choseLanguage.Location = new System.Drawing.Point(372, 8);
            this.label_choseLanguage.Name = "label_choseLanguage";
            this.label_choseLanguage.Size = new System.Drawing.Size(67, 13);
            this.label_choseLanguage.TabIndex = 14;
            this.label_choseLanguage.Text = "Language：";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "network.ico");
            this.imageList1.Images.SetKeyName(1, "camera.png");
            this.imageList1.Images.SetKeyName(2, "warning.png");
            this.imageList1.Images.SetKeyName(3, "Alert_01.ico");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 502);
            this.Controls.Add(this.label_choseLanguage);
            this.Controls.Add(this.cB_ChoseLanguage);
            this.Controls.Add(this.gB_Connections);
            this.Controls.Add(this.group_camInfo);
            this.Controls.Add(this.group_netInfo);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "AVT_IPConfigTool(V.02.21)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.group_netInfo.ResumeLayout(false);
            this.group_netInfo.PerformLayout();
            this.group_camInfo.ResumeLayout(false);
            this.group_camInfo.PerformLayout();
            this.gB_Connections.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TextBox tB_Log;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox group_netInfo;
        private System.Windows.Forms.TextBox tb_Nigateway;
        private System.Windows.Forms.TextBox tb_NiIpmarsk;
        private System.Windows.Forms.TextBox tb_NiIpaddr;
        private System.Windows.Forms.Label label_netGateway;
        private System.Windows.Forms.Label label_netIpmarsk;
        private System.Windows.Forms.Label label_netIpaddr;
        private System.Windows.Forms.Label label_netIpmode;
        private System.Windows.Forms.GroupBox group_camInfo;
        private System.Windows.Forms.TextBox tb_camCurgateway;
        private System.Windows.Forms.TextBox tb_camCurIPMarsk;
        private System.Windows.Forms.TextBox tb_camCurIP;
        private System.Windows.Forms.Label label_camGateway;
        private System.Windows.Forms.Label label_camIpmarsk;
        private System.Windows.Forms.Label label_camIpaddr;
        private System.Windows.Forms.Label label_camIpmode;
        private System.Windows.Forms.Button bt_SaveCamIP;
        private System.Windows.Forms.Button bt_referIP;
        private System.Windows.Forms.ComboBox cb_camConfigMode;
        private System.Windows.Forms.ComboBox cb_NiIpmode;
        private System.Windows.Forms.TextBox tb_NiDiscrip;
        private System.Windows.Forms.Label label_netDiscript;
        private System.Windows.Forms.TextBox tb_CamDiscrip;
        private System.Windows.Forms.Label label_camDiscript;
        private System.Windows.Forms.GroupBox gB_Connections;
        private System.Windows.Forms.Button bt_setNicIP;
        private System.Windows.Forms.TextBox tb_NiMTU;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bT_OpenConnections;
        private System.Windows.Forms.Button bT_RefreshList;
        private System.Windows.Forms.ComboBox cB_ChoseLanguage;
        private System.Windows.Forms.Label label_choseLanguage;
        private System.Windows.Forms.ImageList imageList1;
    }
}

