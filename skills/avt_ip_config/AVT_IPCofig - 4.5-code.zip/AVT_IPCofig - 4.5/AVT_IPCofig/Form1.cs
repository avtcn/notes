﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using AVT.VmbAPINET;
using System.Threading;

namespace AVT_IPCofig
{
    public partial class Form1 : Form
    {

        private Vimba m_Vimba = null;
        bool updateList = false;

        //struct CameraInfo//在左边列表显示IP地址备用
        //{
        //    Camera Cam;
        //    string Name;
        //    string InterfaceName;
        //    string IPmode;
        //    string IPaddr;
        //    string IPmarsk;
        //}        
        // List<CameraInfo> CameraInfoList = new List<CameraInfo>();


        List<NetworkInterface> NetInterfaceList = new List<NetworkInterface>();

        string Cur_cameraId = "NA";//current Camera's ID
        string Cur_niId = "NA";//current NetworkInterface's ID
        string Cur_niName = "NA"; //current NetworkInterface's name

        bool Cur_LanguageIsEnglish ;//false->简体中文；true->english


        bool IsNiIP_Reset = false;

        public Form1()
        {
            InitializeComponent();
        }
                       
         private void LogMessage(string message)
         {
             if (null == message)
             {
                 throw new ArgumentNullException("message");
             }
             tB_Log.AppendText(string.Format("{0:yyyy-MM-dd HH:mm:ss.fff}: {1}", DateTime.Now, message) + "\r\n");
         }

         private void LogError(string message)
         {
             LogMessage(message);

             MessageBox.Show(message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
         }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitNetConnects();
            InitVimba();

           
            cB_ChoseLanguage.Text = "简体中文";//默认中文启动
            Cur_LanguageIsEnglish = false;
            // InitLanguageSet();

            updateList = true;
        }

        void InitLanguageSet()
        {
            if (Cur_LanguageIsEnglish)
            {
                gB_Connections.Text = "NetConnections";
                bT_RefreshList.Text = "Refresh";

                label_choseLanguage.Text = "语言选择:";
                group_netInfo.Text = "Port";
                label_netDiscript.Text = "Discriptions:";
                label_netIpmode.Text = "IPConfigMode:";
                label_netIpaddr.Text = "IPAddress:";
                label_netIpmarsk.Text = "Marsk:";
                label_netGateway.Text = "Gateway:";
                bT_OpenConnections.Text = "Open Local Adapter Settings";
                bt_setNicIP.Text = "Save";

                group_camInfo.Text = "Camera";
                label_camDiscript.Text = "Discriptions:";
                label_camIpmode.Text = "IPConfigMode:";
                label_camIpaddr.Text = "IPAddress:";
                label_camIpmarsk.Text = "Marsk:";
                label_camGateway.Text = "Gateway:";
                bt_referIP.Text = "ReferenceSettings";
                bt_SaveCamIP.Text = "Save";

            }
            else
            {
                gB_Connections.Text = "网络连接";
                bT_RefreshList.Text = "手动刷新";

                label_choseLanguage.Text = "Language:";
                group_netInfo.Text = "网口";
                label_netDiscript.Text = "描述信息:";
                label_netIpmode.Text = "IP获取方式:";
                label_netIpaddr.Text = "IP地址:";
                label_netIpmarsk.Text = "子网掩码:";
                label_netGateway.Text = "默认网关:";
                bT_OpenConnections.Text = "打开本地网络设置";
                bt_setNicIP.Text = "保存";

                group_camInfo.Text = "相机";
                label_camDiscript.Text = "IP描述信息:";
                label_camIpmode.Text = "IP获取方式:";
                label_camIpaddr.Text = "IP地址:";
                label_camIpmarsk.Text = "子网掩码:";
                label_camGateway.Text = "默认网关:";
                bt_referIP.Text = "参考设置";
                bt_SaveCamIP.Text = "保存";

            }
            
        }
        void InitNetConnects()
        {
            NetworkInterface[] Interfaces = NetworkInterface.GetAllNetworkInterfaces();//获取本地计算机上网络接口的对象          
            foreach (NetworkInterface ni in Interfaces)
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                    NetInterfaceList.Add(ni);  //所有网络连接存到列表             
            }
        }

        private void InitVimba()
        {
            try
            {
                Vimba vimba = new Vimba();
                vimba.Startup();
                m_Vimba = vimba;
                m_Vimba.OnCameraListChanged += OnCameraListChange;                      
            }
            catch (Exception exception)
            {
                LogError("Could not startup Vimba API. Reason: " + exception.Message);
            }
        }

        private void OnCameraListChange(VmbUpdateTriggerType reason)
        {
            switch (reason)
            {
                case VmbUpdateTriggerType.VmbUpdateTriggerPluggedIn:
                case VmbUpdateTriggerType.VmbUpdateTriggerPluggedOut:
                    {
                       // UpdateCameraList();
                        updateList = true;
                    }
                    break;

                default:
                    break;
            }
        }

        private void UpdateConnectsList()
        {
            treeView1.ImageList = imageList1;
            treeView1.Nodes.Clear();
            CameraCollection cameras = m_Vimba.Cameras;
            foreach (NetworkInterface NI in NetInterfaceList)
            {
                TreeNode t1 = new TreeNode(NI.Name);
                t1.SelectedImageIndex=0;
                treeView1.Nodes.Add(t1);
                foreach (Camera cam in cameras)
                {
                    string InterfaceID = cam.InterfaceID;
                    if (NI.Name == InterfaceID)
                    {
                        TreeNode t2 = new TreeNode(cam.Id);
                        if (cam.PermittedAccess == VmbAccessModeType.VmbAccessModeConfig)
                        {
                            t2.SelectedImageIndex = 2;
                            t2.ImageIndex = 2;
                        }
                        else {
                            t2.SelectedImageIndex = 1;
                            t2.ImageIndex = 1;
                        }
                        t1.Nodes.Add(t2);
                    }
                }
            }

            treeView1.ExpandAll();
        }     

        private void timer1_Tick(object sender, EventArgs e)//3秒检查一次
        {
            if (updateList)
            {
                UpdateConnectsList();
                updateList = false;
            }

        }

        private void treeView1_MouseDown(object sender, MouseEventArgs e)
        {
            try//点到空的地方会产生异常
            {
                Cur_cameraId = "NA";
                Cur_niId = "NA";
                Cur_niName = "NA";
                group_camInfo.Enabled = false;
                group_netInfo.Enabled = false;

                tb_NiDiscrip.Text = "Unvaliable";
                cb_NiIpmode.Text = "Unvaliable";
                tb_NiIpaddr.Text = "Unvaliable";
                tb_NiIpmarsk.Text = "Unvaliable";
                tb_NiMTU.Text = "Unvaliable";
                tb_NiMTU.BackColor = SystemColors.Control;

                tb_CamDiscrip.Text = "Unvaliable";
                cb_camConfigMode.Text = "Unvaliable";
                tb_camCurIP.Text = "Unvaliable";
                tb_camCurIPMarsk.Text = "Unvaliable";

                if ((sender as TreeView) != null)
                {                   
                    treeView1.SelectedNode = treeView1.GetNodeAt(e.X, e.Y);
                }

                TreeNode tempTree = treeView1.SelectedNode;

                if (tempTree.Parent == null)//第一层为网络连接
                {
                    string adapterName = tempTree.Text;
                    Cur_niName = adapterName;
                    foreach (NetworkInterface NI in NetInterfaceList)
                    {
                        if (NI.Name == adapterName)
                        {
                            string InterfaceID = NI.Id;
                            showNetInterfaceInfoByID(InterfaceID);//显示网口信息
                        }
                    }
                    if (tempTree.Nodes.Count > 0)
                    {
                        TreeNode tempTree2 = tempTree.Nodes[0];
                        string cameraID = tempTree2.Text;
                        Cur_cameraId = cameraID;
                        showCameraInfoByID(cameraID);//显示相机信息
                    }                   
                }
                else //第二层为相机
                {
                    string cameraID = tempTree.Text;
                    showCameraInfoByID(cameraID);//显示相机信息
                    TreeNode tempTree2 = tempTree.Parent;
                    string adapterName = tempTree2.Text;
                    Cur_niName = adapterName;
                    foreach (NetworkInterface adapter in NetInterfaceList)
                    {
                        if (adapter.Name == adapterName)
                        {
                            string InterfaceID = adapter.Id;
                            showNetInterfaceInfoByID(InterfaceID);//显示网口信息
                        }
                    }
                }
            }
            catch 
            { 
            }
        }

        void showNetInterfaceInfoByID(string NetworkInterfaceId)//该方式无法获取本地连接的可命名名称
        {
            ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection nics = mc.GetInstances();
            foreach (ManagementObject nic in nics)
            {
                //try
                if (Convert.ToBoolean(nic["ipEnabled"]) == true)
                {
                    string nicId = nic["SettingID"].ToString();//
                    if (nicId == NetworkInterfaceId)
                    {
                        Cur_niId = NetworkInterfaceId;

                        tb_NiDiscrip.Text = nic["Description"].ToString();
                        bool IsDHCP = (bool)nic.GetPropertyValue("DHCPEnabled");
                        tb_NiIpaddr.Text = (nic["IPAddress"] as String[])[0];//IP地址
                        tb_NiIpmarsk.Text = (nic["IPSubnet"] as String[])[0];//子网掩码
                        //try
                        //{                         
                        //    uint mtu = Convert.ToUInt32(nic.GetPropertyValue("MTU"));
                        //    tb_NicMTU.Text = mtu.ToString();//该方式获取不到？？
                        //}
                        //catch
                        //{
                        //    tb_NicMTU.Text = "Unvaliable";
                        //}
                        int mtu = GetIPv4MTUByInterfaceName(Cur_niName);
                        if (mtu < 8999)
                            tb_NiMTU.BackColor = Color.LemonChiffon;
                        tb_NiMTU.Text = mtu.ToString();

                        if ((bool)nic.GetPropertyValue("DHCPEnabled"))
                        {
                            cb_NiIpmode.Text = "DHCP";
                        }
                        else
                        {
                            cb_NiIpmode.Text = "Persistent";
                            //tb_Nicgateway.Text = (nic["DefaultIPGateway"] as String[])[0];//默认网关                         
                        }
                        group_netInfo.Enabled = true;

                        break;
                    }

                }
                //catch 
                //{ }


            }
        }
        void showCameraInfoByID(string cameraID)
        {

            Cur_cameraId = cameraID;
            
            try
            {
                Camera m_camera = m_Vimba.OpenCameraByID(Cur_cameraId, VmbAccessModeType.VmbAccessModeConfig);                               
                if (null == m_camera)
                {
                    string errstr = Cur_LanguageIsEnglish ? "<Can find such a camera>" : "<找不到对应的相机>";
                    LogMessage("errstr");
                }
                else
                {
                    try
                    {                       
                        long Cur_ipAddr = m_camera.Features["GevCurrentIPAddress"].IntValue;
                        long Cur_ipMarsk = m_camera.Features["GevCurrentSubnetMask"].IntValue;

                        string ipAddr = IntToIp(Cur_ipAddr);
                        string ipMarsk = IntToIp(Cur_ipMarsk);

                        tb_CamDiscrip.Text = m_camera.Name + "(" + m_camera.SerialNumber + ")"; ;
                        cb_camConfigMode.Text = m_camera.Features["GevIPConfigurationMode"].EnumValue.ToString();
                        tb_camCurIP.Text = ipAddr;
                        tb_camCurIPMarsk.Text = ipMarsk;
                        m_camera.Close();//为了防止冲突，关闭相机
                        group_camInfo.Enabled = true;
                    }
                    catch
                    {

                        string errstr = Cur_LanguageIsEnglish ? "<read camera features fail>" : "<相机参数读取异常>";
                        LogMessage("errstr");
                        m_camera.Close();//为了防止冲突，关闭相机
                    }

                 }               

            }
            catch
            {
                string errstr = Cur_LanguageIsEnglish ? "<Open Config mode fail,Please check whether the camera is occupied by other programs>" : "<相机配置模式打开失败，请检查相机是否被占用>";
                LogMessage(errstr);
            }
        }

        private string GetIPv4AddressByInterfaceName(string InterfaceName)
        {
            NetworkInterface[] Interfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface ni in Interfaces)
            {
                if (ni.Name == InterfaceName)
                {

                    UnicastIPAddressInformationCollection unicastIPAddressInformation = ni.GetIPProperties().UnicastAddresses;
                    foreach (var item in unicastIPAddressInformation)
                    {
                        if (item.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            return item.Address.ToString();
                        }
                    }
                }
            }
            return "999";
        }

        private int GetIPv4MTUByInterfaceName(string InterfaceName)
        {
            foreach (NetworkInterface NI in NetInterfaceList)
            {
                if (NI.Name == InterfaceName)
                {
                    try
                    {
                        IPInterfaceProperties properties = NI.GetIPProperties();
                        if (NI.Supports(NetworkInterfaceComponent.IPv4))
                        {
                            IPv4InterfaceProperties ipv4 = properties.GetIPv4Properties();
                            return ipv4.Mtu;
                        }
                    }
                    catch
                    {
                        return 1500;
                    }
                }
            }
            return 1500;
        }

        public string IntToIp(long ipInt)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append((ipInt & 0xFF) & 0xFF).Append(".");
            sb.Append((ipInt >> 8) & 0xFF).Append(".");
            sb.Append((ipInt >> 16) & 0xFF).Append(".");
            sb.Append((ipInt >> 24));           
            return sb.ToString();
        }

        public long IpToInt(string ip)
        {
            char[] separator = new char[] { '.' };
            string[] items = ip.Split(separator);
            return long.Parse(items[0]) 
                    | long.Parse(items[1]) << 8
                    | long.Parse(items[2]) << 16
                    | long.Parse(items[3])<<24;

        }

       

        private void bt_AutoModify_Click(object sender, EventArgs e)
        {
            if (cb_NiIpmode.Text == "DHCP")
            {
                cb_camConfigMode.Text = "DHCP";
            }
            else
            {
                cb_camConfigMode.Text = "Persistent";
                tb_camCurIPMarsk.Text = tb_NiIpmarsk.Text;

                string strIp = tb_NiIpaddr.Text;
                char[] separator = new char[] { '.' };
                string[] items = strIp.Split(separator);
                string strtep = items[3];
                int newIp = 20;
                int.TryParse(strtep, out newIp);
                newIp += 1;
                tb_camCurIP.Text = items[0] + "." + items[1] + "." + items[2] + "." + newIp.ToString();
            }
            
        }
        private void bt_SaveCamIP_Click(object sender, EventArgs e)
        {
            if (tb_NiIpaddr.Text == tb_camCurIP.Text)
            {
                string errstr = Cur_LanguageIsEnglish ? "<IP address Format error>" : "<相机IP地址输入格式错误>";
                LogMessage(errstr);
            }
            else
            {
                group_camInfo.Enabled = false;//修改相机IP可能会导致连接中断
                Application.DoEvents();

                if (cb_camConfigMode.Text == "DHCP")
                {
                    SaveCameraIP(false);
                }
                else
                {
                    IPAddress ip;
                    try
                    {
                        ip = IPAddress.Parse(tb_camCurIP.Text);//判断输入是否合法
                        ip = IPAddress.Parse(tb_camCurIPMarsk.Text);
                        SaveCameraIP(true);
                    }
                    catch (Exception error)
                    {
                        string errstr = Cur_LanguageIsEnglish ? "<Input Camera IP format error>" : "<相机IP地址输入格式错误>";
                        LogMessage(errstr + error.Message);
                    }
                }
            }
            
        }
      
        private void SaveCameraIP(bool staticIP)
        {

            if (Cur_cameraId != "NA")
            {
                try
                {
                    Camera m_camera = m_Vimba.OpenCameraByID(Cur_cameraId, VmbAccessModeType.VmbAccessModeConfig);
                    if (null == m_camera)
                    {
                        string errstr = Cur_LanguageIsEnglish ? "<Can find such a camera>" : "<找不到对应的相机>";
                        LogMessage("errstr");
                    }
                    else
                    {
                        try
                        {
                            string ipConfigMode = cb_camConfigMode.Text;
                            m_camera.Features["GevIPConfigurationMode"].EnumValue = ipConfigMode;
                            if (staticIP)
                            {
                                string Cur_ipAddress = tb_camCurIP.Text;
                                string Cur_ipMarsk = tb_camCurIPMarsk.Text;
                                long ipAddress = IpToInt(Cur_ipAddress);
                                long ipMarsk = IpToInt(Cur_ipMarsk);
                                m_camera.Features["GevPersistentIPAddress"].IntValue = ipAddress;
                                m_camera.Features["GevPersistentSubnetMask"].IntValue = ipMarsk;
                            }                                                        
                            m_camera.Features["GevIPConfigurationApply"].RunCommand();
                            //while (false == m_camera.Features["GevIPConfigurationApply"].IsCommandDone())
                            //{
                            //    //会一直卡在这
                            //}
                            string errstr = Cur_LanguageIsEnglish ? "success to set camera IP" : "相机IP设置成功";
                            LogMessage(errstr);
                            //
                            Thread.Sleep(1000);
                            m_camera.Close();
                            Thread.Sleep(2500);//等待vimba更新列表
                            updateList = true;
                        }
                        catch
                        {
                            string errstr = Cur_LanguageIsEnglish ? "<error to set camera IP >" : "<相机IP设置异常>";
                            LogMessage(errstr);
                            m_camera.Close();
                        }
                    }

                }
                catch
                {
                    string errstr = Cur_LanguageIsEnglish ? "<Open Config Mode error,Please check whether the camera is occupied by other programs >" : "<相机配置模式打开失败，请检查相机是否被占用>";
                    LogMessage(errstr);
                }
            }
        }
        private void bt_setNicIP_Click(object sender, EventArgs e)
        {
            if (tb_NiIpaddr.Text == tb_camCurIP.Text)
            {
                string errstr = Cur_LanguageIsEnglish ? "<IP address Format error>" : "<本地连接IP地址输入格式错误>";
                LogMessage(errstr);
            }
            else
            {
                group_netInfo.Enabled = false;//更改设置会导致网络连接不可用
                group_camInfo.Enabled = false;
                Application.DoEvents();

                if (cb_NiIpmode.Text == "DHCP")
                {
                    SaveNiIP(false);
                }
                else
                {
                    IPAddress ip;
                    try
                    {
                        ip = IPAddress.Parse(tb_NiIpaddr.Text);//判断输入是否合法
                        ip = IPAddress.Parse(tb_NiIpmarsk.Text);

                        SaveNiIP(true);
                    }
                    catch (Exception error)
                    {
                        IsNiIP_Reset = false;
                        string errstr = Cur_LanguageIsEnglish ? "<IP address Format error>" : "<本地连接IP地址输入格式错误>";
                        LogMessage(errstr + error.Message);
                    }
                }
                if (IsNiIP_Reset)
                {
                    m_Vimba.Shutdown();
                    Thread.Sleep(1500);
                    m_Vimba.Startup();
                }
                bt_setNicIP.Enabled = true;
            }
        }
        private bool SaveNiIP(bool StaicIP)
        {
            ManagementClass wmi = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = wmi.GetInstances();
            ManagementBaseObject inPar = null;
            ManagementBaseObject outPar = null;
            string str = "";
            string[] ip = new string[1];// 
            ip[0] = tb_NiIpaddr.Text;
            string[] submask = new string[1];
            submask[0] = tb_NiIpmarsk.Text;

            foreach (ManagementObject mo in moc)
            {
 
                if (!(bool)mo["IPEnabled"])
                    continue;
                string niId = mo["SettingID"].ToString();//
                if (Cur_niId == niId)
                {
                    
                    try
                    {
                        if (cb_NiIpmode.Text == "DHCP")
                        {
                            mo.InvokeMethod("SetDNSServerSearchOrder", null);
                            mo.InvokeMethod("EnableDHCP", null);
                            IsNiIP_Reset = true;
                        }
                        else if (ip != null && submask != null)
                        {                           
                            inPar = mo.GetMethodParameters("EnableStatic");
                            inPar["IPAddress"] = ip;
                            inPar["SubnetMask"] = submask;
                            outPar = mo.InvokeMethod("EnableStatic", inPar, null);
                            str = outPar["returnvalue"].ToString();
                            IsNiIP_Reset = true;
                            string errstr = Cur_LanguageIsEnglish ? "Success to set local connection IP address" : "本地IP设置成功";
                            LogMessage(errstr);
                            return (str == "0" || str == "1") ? true : false;                             
                        }                                             
                    }
                    catch(Exception error)
                    {
                        string errstr = Cur_LanguageIsEnglish ? "<No permission to change the local connection IP address>" : "<没有修改本地连接IP地址的权限>";
                        LogMessage(errstr + error.Message);
                    }
                }
                
            }
            return false;
        }
       
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_Vimba.Shutdown();
        }

        private void bT_OpenConnections_Click(object sender, EventArgs e)
        {
            group_netInfo.Enabled = false;//更改设置会导致网络连接不可用
            group_camInfo.Enabled = false;
            Application.DoEvents();         
            System.Diagnostics.Process.Start("ncpa.cpl");//CPL->Control Panel Item

        }

        private void bT_RefreshList_Click(object sender, EventArgs e)//本地连接修改后Vimba需要重启才能找到相机
        {
            bT_RefreshList.Enabled = false;
            Application.DoEvents();

            m_Vimba.Shutdown();
            Thread.Sleep(1500);
            m_Vimba.Startup();
            bT_RefreshList.Enabled = true;
        }

        private void cB_ChoseLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {      
            Cur_LanguageIsEnglish = (cB_ChoseLanguage.SelectedIndex<1)?false:true;
            InitLanguageSet();          
        }


    }
}
