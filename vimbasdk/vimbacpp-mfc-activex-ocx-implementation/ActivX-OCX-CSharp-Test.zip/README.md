# Introduction 
C# Test Program for ActiveX OCX plugin from MFCActiveXControl2 project.

![](screenshot.png)


# Getting Started

## AxMFCActiveXControl2Lib.AxMFCActiveXControl2 axMFCActiveXControl21;
From MFCActiveXControl2 project.

## AVT Manta G895B Camera
Mono(black/white) mode tested.


# Build and Test

## Microsoft Visual Studio Community 2017
## Version 15.5.0



# Contribute
