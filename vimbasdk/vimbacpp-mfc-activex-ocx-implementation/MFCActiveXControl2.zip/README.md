# Start
* Vimba C++ SDK from Vimba version 2.1.3
* Vimba API Version: 1.7.0
* Visual Studio Community 2017


# Build 

Put this sample in Vimba C++ examles folder:
```
C:\Users\Public\Documents\Allied Vision\Vimba_2.1\VimbaCPP_Examples\MFCActiveXControl2
```

Build ActiveX OCX first and then register into your system:
```
C:\WINDOWS\system32>regsvr32.exe "C:\Users\Public\Documents\Allied Vision\Vimba_2.1\VimbaCPP_Examples\MFCActiveXControl2\Debug\MFCActiveXControl2.ocx"
```

To Unregister: use `/u` option in above command.


# Test
Try above ActiveX OCX in C# forms from project: `ActivX-OCX-CSharp-Test`


# Screenshot
![](screenshot.png)



