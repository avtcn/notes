

#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <chrono>


#include "VmbTransform.h"

#include "FrameObserver.h"
//#include "Bitmap.h"


//
// We pass the camera that will deliver the frames to the constructor
//
// Parameters:
//  [in]    pCamera             The camera the frame was queued at
//
FrameObserver::FrameObserver(CameraPtr pCamera, bool bRGBValue, int mode, HWND topWnd)
    :   IFrameObserver( pCamera )
    ,   m_bRGB( bRGBValue )
	,   m_modeTrigger(mode)
	,   m_wndParent(topWnd)
{ 
	hSemaphore = CreateSemaphore(NULL, 0, 1, L"Buffered_Images_Amount"); 
}


FrameObserver::~FrameObserver()
{
	if (hSemaphore)
	{
		CloseHandle(hSemaphore);
		hSemaphore = NULL;
	}
}

//
// Gets the current timestamp for interval measurement
//
double FrameObserver::GetTime()
{
    double dTime = 0.0;


    return dTime;
}

//
// Prints out frame parameters such as 
// - width
// - height
// - pixel format
//
// Parameters:
//  [in]    pFrame          The frame to work on
//
void PrintFrameInfo( const FramePtr &pFrame )
{
    std::cout<<" Size:";
    VmbUint32_t     nWidth = 0;
    VmbErrorType    res;
    res = pFrame->GetWidth(nWidth);
    if( VmbErrorSuccess == res )
    {
        std::cout<<nWidth;
    }
    else
    {
        std::cout<<"?";
    }

    std::cout<<"x";
    VmbUint32_t nHeight = 0;
    res = pFrame->GetHeight(nHeight);
    if( VmbErrorSuccess == res )
    {
        std::cout<< nHeight;
    }
    else
    {
        std::cout<<"?";
    }

    std::cout<<" Format:";
    VmbPixelFormatType ePixelFormat = VmbPixelFormatMono8;
    res = pFrame->GetPixelFormat( ePixelFormat );
    if( VmbErrorSuccess == res )
    {
        std::cout<<"0x"<<std::hex<<ePixelFormat<<std::dec;
    }
    else
    {
        std::cout<<"?";
    }
}

//
// Prints out frame status codes as readable status messages
//
// Parameters:
//  [in]    eFrameStatus    The error code to be converted and printed out
//
void PrintFrameStatus( VmbFrameStatusType eFrameStatus )
{
    switch( eFrameStatus )
    {
    case VmbFrameStatusComplete:
        std::cout<<"Complete";
        break;

    case VmbFrameStatusIncomplete:
        std::cout<<"Incomplete";
        break;

    case VmbFrameStatusTooSmall:
        std::cout<<"Too small";
        break;

    case VmbFrameStatusInvalid:
        std::cout<<"Invalid";
        break;

    default:
        std::cout<<"unknown frame status";
        break;
    }
}


//
// This is our callback routine that will be executed on every received frame.
// Triggered by the API.
//
// Parameters:
//  [in]    pFrame          The frame returned from the API
//
void FrameObserver::FrameReceived( const FramePtr pFrame )
{
    if(! SP_ISNULL( pFrame ) )
    {
		OutputDebugString(L"FrameReceived()\n");

		// Calculate FPS
		// FPS calculation, print image sequence information
		long long tGap = 1; // 1ms
		queueTickets.push(tickets());
		while (queueTickets.size() > 11) {
			queueTickets.pop();
		}
		if (queueTickets.size() >= 2) {
			tGap = queueTickets.back() - queueTickets.front(); 
			double fGapTwoShots = (tGap * 1.0) / (queueTickets.size() - 1); 
			//std::cout << std::fixed; 
			//std::cout << "Fetching image i = " << i << std::setprecision(4) << ", gap    : " << fGapTwoShots << " ms,      FPS = " << 1000.0 / fGapTwoShots << std::endl;
			m_fFps = 1000.0f / fGapTwoShots;
		}

        VmbFrameStatusType status;
        VmbErrorType Result;
        Result = SP_ACCESS( pFrame)->GetReceiveStatus( status);
        if( VmbErrorSuccess == Result && VmbFrameStatusComplete == status)
		{
			VmbUint32_t nImgSize = 0;
			pFrame->GetImageSize(nImgSize);
            std::vector<VmbUchar_t> TransformedData(nImgSize);

			VmbUchar_t *DataBegin = NULL; 
            if ( m_bRGB )
            {
				// TODO: color image processing 
            }
			else
			{
				// For mono8 image type 
				//Result = TransformImage(pFrame, TransformedData, "MONO8"); 
				pFrame->GetImage(DataBegin);
				memcpy(&TransformedData[0], DataBegin, nImgSize); 
			}

			m_mutex.Lock();

			m_framesQueue.push(TransformedData);

			// Deleted the oldest buffers to avoid memory flood
			while (m_framesQueue.size() > 20) {
				//std::cout << "WARNING: buffered frames flood size = " << m_framesQueue.size() << "\n";
				m_framesQueue.pop();
			}

			m_mutex.Unlock();


			// notify the main thread that the frame buffer is ready
			ReleaseSemaphore(hSemaphore, 1, NULL);


			if (VmbErrorSuccess == Result && TransformedData.size() >= 3)
			{
				VmbUint32_t nImageSize = 0;
				pFrame->GetImageSize(nImageSize);
				VmbUint32_t nWidth = 0;
				pFrame->GetWidth(nWidth);
				m_nWidth = nWidth;
				VmbUint32_t nHeight = 0;
				pFrame->GetHeight(nHeight);
				m_nHeight = nHeight;

				VmbUchar_t *pImage = NULL;
				pFrame->GetImage(pImage);

				/*
				//AVTBitmap bitmap;

				// Only Mono image now!!!
				bitmap.colorCode = ColorCodeMono8;

				bitmap.bufferSize = nImageSize;
				bitmap.width = nWidth;
				bitmap.height = nHeight;
				*/

				// Using CBitmap format to process in memory
				//CBitmap bitmap;
				//bitmap.CreateBitmap();

				/*
				m_Image.Create(nWidth, -1*(int)nHeight, 24); // The height of the CImage bitmap, in pixels. If nHeight is positive, the bitmap is a bottom-up DIB and its origin is the lower left corner. If nHeight is negative, the bitmap is a top-down DIB and its origin is the upper left corner.
				VmbPixelFormatType ePixelFormat = VmbPixelFormatMono8;
				CopyToImage(nWidth, nHeight, pImage, ePixelFormat, m_Image);
				m_Image.Save(L"ATL-Image.bmp", Gdiplus::ImageFormatBMP);
				m_Image.Destroy();
				*/


				/*
				// Create the bitmap
				if (0 == AVTCreateBitmap(&bitmap, pImage))
				{
					//std::cout << "Could not create bitmap.\n";
				}
				else
				{
					// Save the bitmap
					if (0 == AVTWriteBitmapToFile(&bitmap, "Manta-G895B.bmp"))
					{
						//std::cout << "Could not write bitmap to file.\n";
					}
					else
					{
						//std::cout << "Bitmap successfully written to file \"" << pFileName << "\"\n" ;
						// Release the bitmap's buffer
						if (0 == AVTReleaseBitmap(&bitmap))
						{
							std::cout << "Could not release the bitmap.\n";
							//err = VmbErrorInternalFault;
						}
					}
				}
				*/

				// TODO: And notify the view about it
				//CWnd * pWnd = AfxGetMainWnd();
                //pWnd->PostMessage( WM_FRAME_READY, 0L );
				//SendMessage(m_wndParent, WM_FRAME_READY, (WPARAM)m_wndParent, 20090215L); 
				CString strPostMessageToMainWnd;
				strPostMessageToMainWnd.Format(L"FrameObserver::FrameReceived(), notify m_wndParent = %d\n", m_wndParent);
				OutputDebugString(strPostMessageToMainWnd);

				// fps * 1000
				PostMessage(m_wndParent, WM_FRAME_READY, (WPARAM)m_wndParent, (int)(m_fFps * 1000));

				

				/*
				std::cout << "Mono image Transform to buffer and print first three bytes : \n";
				char old_fill_char = std::cout.fill('0');
				std::cout<<std::hex <<"1st = 0x"<<std::setw(2)<<(int)TransformedData[0]<<" "
									<<"2nd = 0x"<<std::setw(2)<<(int)TransformedData[1]<<" "
									<<"3rd = 0x"<<std::setw(2)<<(int)TransformedData[2]<<std::dec<<"\n";
				std::cout.fill( old_fill_char );

				std::cout << std::dec << "image size = " << TransformedData.size() << ", Queue Size = " << m_framesQueue.size() << "\n";
				std::cout << std::dec;
				*/
			}
			else
			{
				//std::cout << "Transformation failed.\n";
			}

        }
        else
        {
            //std::cout<<"frame incomplete\n";
        }
    }
    else
    {
        //std::cout <<" frame pointer NULL\n";
    }

    m_pCamera->QueueFrame( pFrame );
}


long FrameObserver::WaitForImageReady(int timeout_milliseconds) 
{ 
	return WaitForSingleObject(hSemaphore, timeout_milliseconds); 
}



std::vector<VmbUchar_t> FrameObserver::GetImage()
{
	std::vector<VmbUchar_t> frameReturn;

	m_mutex.Lock();

	if(m_framesQueue.size() > 0) {
		frameReturn = m_framesQueue.front(); // Get first element of queue
		m_framesQueue.pop(); // Delete first element of the queue
	} 

	m_mutex.Unlock(); 

	return frameReturn;
}


std::vector<VmbUchar_t> FrameObserver::GetImage(int & nBufferSize , int & iWidth, int & iHeight)
{
	std::vector<VmbUchar_t> frameReturn;

	iWidth = m_nWidth;
	iHeight = m_nHeight;

	m_mutex.Lock();

	nBufferSize = m_framesQueue.size();

	if(m_framesQueue.size() > 0) {
		frameReturn = m_framesQueue.front(); // Get first element of queue
		m_framesQueue.pop(); // Delete first element of the queue
	}
	else {
		nBufferSize = -1;
		iWidth = -1;
		iHeight = -1;
	}

	m_mutex.Unlock(); 

	return frameReturn;
}

//
// Copies the content of a byte buffer to a MFC image with respect to the image's alignment
//
// Parameters:
//  [in]    pInbuffer       The byte buffer as received from the cam
//  [in]    ePixelFormat    The pixel format of the frame
//  [out]   OutImage        The filled MFC image
//
void FrameObserver::CopyToImage( int width, int height, VmbUchar_t *pInBuffer, VmbPixelFormat_t ePixelFormat, ATL::CImage &OutImage )
{
	const int               nHeight = height;
	const int               nWidth = width;
    const int               nStride         = OutImage.GetPitch();
    const int               nBitsPerPixel   = OutImage.GetBPP();
    VmbError_t              Result;
    if( ( nWidth*nBitsPerPixel ) /8 != nStride )
    {
        //Log( _TEXT( "Vimba only supports stride that is equal to width." ), VmbErrorWrongType );
		OutputDebugString(L"Vimba only supports stride that is equal to width." );
        return;
    }
    VmbImage                SourceImage,DestinationImage;
    SourceImage.Size        = sizeof( SourceImage );
    DestinationImage.Size   = sizeof( DestinationImage );

    SourceImage.Data        = pInBuffer;
    DestinationImage.Data   = OutImage.GetBits();

    Result = VmbSetImageInfoFromPixelFormat( ePixelFormat, nWidth, nHeight, &SourceImage );
    if( VmbErrorSuccess != Result )
    {
        //Log( _TEXT( "Error setting source image info." ), static_cast<VmbErrorType>( Result ) ); 
		OutputDebugString(L"Error setting source image info.");
        return;
    }
    static const std::string DisplayFormat( "BGR24" );
    Result = VmbSetImageInfoFromString( DisplayFormat.c_str(),DisplayFormat.size(), nWidth,nHeight, &DestinationImage );
    if( VmbErrorSuccess != Result )
    {
        //Log( _TEXT( "Error setting destination image info." ),static_cast<VmbErrorType>( Result ) );
		OutputDebugString(L"Error setting destination image info." );
        return;
    }
    Result = VmbImageTransform( &SourceImage, &DestinationImage,NULL,0 );
    if( VmbErrorSuccess != Result )
    {
        //Log( _TEXT( "Error transforming image." ), static_cast<VmbErrorType>( Result ) );
		OutputDebugString(L"Error transforming image." );
    }
}


// Milliseconds of time since epoch
long long FrameObserver::tickets()
{
	std::chrono::milliseconds ms = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now().time_since_epoch() );
	return ms.count(); 
}


