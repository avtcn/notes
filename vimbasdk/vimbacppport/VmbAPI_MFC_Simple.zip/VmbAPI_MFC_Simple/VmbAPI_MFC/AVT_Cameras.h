//#pragma once

#include "VimbaCPP/Include/VimbaCPP.h"//����VimbaCPPͷ�ļ�
using namespace AVT::VmbAPI;//����VmbAPI�����ռ�

#include <string>
#include <sstream>
#include <iostream>

#ifndef UNICODE
    typedef std::string             string_type;
    typedef std::ostringstream      string_stream_type;
#else
    typedef std::wstring            string_type;
    typedef std::wostringstream     string_stream_type;
#endif

class AVT_Cameras
{
public:
	AVT_Cameras();
	~AVT_Cameras();

	 
    VmbErrorType        StartUp();  
    void                ShutDown();
	string_type         GetVersion() const;

private:
	VimbaSystem &   m_system;//VimbaSystem�ǲ��������Ψһ���
};


