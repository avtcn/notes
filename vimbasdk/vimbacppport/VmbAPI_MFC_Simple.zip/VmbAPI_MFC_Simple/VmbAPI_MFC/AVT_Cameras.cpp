#include "StdAfx.h"
#include "AVT_Cameras.h"
#include "Common/StreamSystemInfo.h"

AVT_Cameras::AVT_Cameras(): m_system( VimbaSystem::GetInstance() )
{
	
}
AVT_Cameras::~AVT_Cameras()
{
}
VmbErrorType AVT_Cameras::StartUp()
{
    VmbErrorType res;

    // Start Vimba
    res = m_system.Startup();   
    return res;
}
void AVT_Cameras::ShutDown()
{
    // Release Vimba
    m_system.Shutdown();
}
string_type AVT_Cameras::GetVersion() const
{
	string_stream_type os;
    os << m_system;
    return os.str();

	//----��������û��#include "Common/StreamSystemInfo.h"�Ĵ��룬�����������ˣ�ע������------
    /* string_stream_type os;
     VmbVersionInfo_t info;
    if (VmbErrorSuccess != m_system.QueryVersion( info ))
    {
        throw std::exception();
    }
    os << info.major << "." << info.minor << "." << info.patch;
    return os.str();*/
}