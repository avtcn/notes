﻿
// VmbAPI_MFCDlg.cpp : 实现文件
//

#include "stdafx.h"
#include "VmbAPI_MFC.h"
#include "VmbAPI_MFCDlg.h"
#include "afxdialogex.h"
//#include "VimbaCPP/Include/VimbaCPP.h"//引用VimbaCPP头文件

#include <iostream>
#include <sstream>
#include <string>

#include "VmbTransform.h"

#define NUM_COLORS 3
#define BIT_DEPTH 8


using AVT::VmbAPI::FramePtr;
using AVT::VmbAPI::CameraPtrVector;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CVmbAPI_MFCDlg 对话框




CVmbAPI_MFCDlg::CVmbAPI_MFCDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CVmbAPI_MFCDlg::IDD, pParent)
	, m_bIsStreaming( false )//注意这里，初始化要设为False
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVmbAPI_MFCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PICTURE_STREAM, m_PictureBoxStream);
	DDX_Control(pDX, IDC_BUTTON_STARTSTOP, m_ButtonStartStop);
	DDX_Control(pDX, IDC_LIST_CAMERAS, m_ListBoxCameras);
	DDX_Control(pDX, IDC_LIST_LOG, m_ListLog);
}

BEGIN_MESSAGE_MAP(CVmbAPI_MFCDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_SYSCOMMAND()//设置关闭时的动作
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_STARTSTOP, &CVmbAPI_MFCDlg::OnBnClickedButtonStartstop)
	 // Here we add the event handlers for Vimba events
    ON_MESSAGE( WM_FRAME_READY, OnFrameReady )//在FrameObserver定义
    ON_MESSAGE( WM_CAMERA_LIST_CHANGED, OnCameraListChanged )//在CameraObserver定义

END_MESSAGE_MAP()


// CVmbAPI_MFCDlg 消息处理程序

BOOL CVmbAPI_MFCDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	VmbErrorType err = m_AVT_Cameras.StartUp();
    string_type DialogTitle( _TEXT( "AsynchronousGrab (MFC version) Vimba V" ) );
    SetWindowText( ( DialogTitle+m_AVT_Cameras.GetVersion() ).c_str() );
    Log( _TEXT( "Starting Vimba" ), err );
    if( VmbErrorSuccess == err )
    {
        // Initially get all connected cameras
        UpdateCameraListBox();
        string_stream_type strMsg;
        strMsg << "Cameras found..." << m_cameras.size();
        Log( strMsg.str() );
    }
    
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。
void CVmbAPI_MFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	 if ( SC_CLOSE == nID )
    {
        // Before we close the application we stop Vimba
        m_AVT_Cameras.ShutDown();//关闭Vimba对象
        
    }
    
    CDialog::OnSysCommand(nID, lParam);
	
}
template <typename T>
CRect fitRect( T w, T h, const CRect &dst)
{
    double sw = static_cast<double>( dst.Width() ) / w;
    double sh = static_cast<double>( dst.Height() ) / h;
    double s = min( sw, sh );
    T new_w = static_cast<T>( w * s );
    T new_h = static_cast<T>( h * s );
    T off_w = (1 + dst.Width() - new_w) /2;
    T off_h = (1 + dst.Height() - new_h) /2;
    return CRect(off_w,off_h, off_w + new_w, off_h + new_h );
}
void CVmbAPI_MFCDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{		
        CDialog::OnPaint();

        if( NULL != m_Image )
        {
            CPaintDC dc( &m_PictureBoxStream );
            CRect rect;
            m_PictureBoxStream.GetClientRect( &rect );
            if( m_ClearBackground)
            {
                m_ClearBackground = false;
                CBrush clearBrush( GetSysColor( COLOR_BTNFACE) );
                dc.FillRect( rect, &clearBrush);
            }
            rect = fitRect( m_Image.GetWidth(), m_Image.GetHeight(), rect );
            // HALFTONE enhances image quality but decreases performance
            dc.SetStretchBltMode( HALFTONE );
            m_Image.StretchBlt( dc.m_hDC, rect );
        }
    }
	}


//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CVmbAPI_MFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CVmbAPI_MFCDlg::OnBnClickedButtonStartstop()
{
	// TODO: ÔÚ´ËÌí¼Ó¿Ø¼þÍ¨Öª´¦Àí³ÌÐò´úÂë
	VmbErrorType err;
    int nRow = m_ListBoxCameras.GetCurSel();

    if( false == m_bIsStreaming )
    {
        if( -1 < nRow )
        {
            // Start acquisition
            err = m_AVT_Cameras.StartContinuousImageAcquisition( m_cameras[nRow] );
            // Set up image for MFC picture box
            if (    VmbErrorSuccess == err
                 && NULL == m_Image )
            {
                m_Image.Create(  m_AVT_Cameras.GetWidth(),
                                -m_AVT_Cameras.GetHeight(),
                                NUM_COLORS * BIT_DEPTH );
                m_ClearBackground = true;
            }
            Log( _TEXT( "Starting Acquisition" ), err );
            m_bIsStreaming = VmbErrorSuccess == err;
        }
        else
        {
            Log( _TEXT( "Please select a camera." ) );
        }
    }
    else
    {
        m_bIsStreaming = false;
        // Stop acquisition
        err = m_AVT_Cameras.StopContinuousImageAcquisition();
        m_AVT_Cameras.ClearFrameQueue();
        if( NULL != m_Image )
        {
            m_Image.Destroy();
        }
        Log( _TEXT( "Stopping Acquisition" ), err );
    }

    if( false == m_bIsStreaming )
    {
        m_ButtonStartStop.SetWindowText( _TEXT( "Start Image Acquisition" ) );
    }
    else
    {
        m_ButtonStartStop.SetWindowText( _TEXT( "Stop Image Acquisition" ) );
    }

}

LRESULT CVmbAPI_MFCDlg::OnFrameReady( WPARAM status, LPARAM lParam )
{
    if( true == m_bIsStreaming )
    {
        // Pick up frame
        FramePtr pFrame = m_AVT_Cameras.GetFrame();
        if( SP_ISNULL( pFrame) )
        {
            Log( _TEXT("frame ptr is NULL, late call") );
            return 0;
        }
        // See if it is not corrupt
        if( VmbFrameStatusComplete == status )
        {
            VmbUchar_t *pBuffer;
            VmbUchar_t *pColorBuffer = NULL;
            VmbErrorType err = pFrame->GetImage( pBuffer );
            if( VmbErrorSuccess == err )
            {
                VmbUint32_t nSize;
                err = pFrame->GetImageSize( nSize );
                if( VmbErrorSuccess == err )
                {
                    VmbPixelFormatType ePixelFormat = m_AVT_Cameras.GetPixelFormat();
                    CopyToImage( pBuffer,ePixelFormat, m_Image );
                    // Display it
                    RECT rect;
                    m_PictureBoxStream.GetWindowRect( &rect );
                    ScreenToClient( &rect );
                    InvalidateRect( &rect, false );
                }
            }
        }
        else
        {
            // If we receive an incomplete image we do nothing but logging
            Log( _TEXT( "Failure in receiving image" ), VmbErrorOther );
        }

        // And queue it to continue streaming
        m_AVT_Cameras.QueueFrame( pFrame );
    }

    return 0;
}

//
// This event handler is triggered through a MFC message posted by the camera observer
//
// Parameters:
//  [in]    reason          The reason why the callback of the observer was triggered (plug-in, plug-out, ...)
//  [in]    lParam          [Unused, demanded by MFC signature]
//
// Returns:
//  Nothing, always returns 0
//
LRESULT CVmbAPI_MFCDlg::OnCameraListChanged( WPARAM reason, LPARAM lParam )
{
    bool bUpdateList = false;

    // We only react on new cameras being found and known cameras being unplugged
    if( AVT::VmbAPI::UpdateTriggerPluggedIn == reason )
    {
        Log( _TEXT( "Camera list changed. A new camera was discovered by Vimba." ) );
        bUpdateList = true;
    }
    else if( AVT::VmbAPI::UpdateTriggerPluggedOut == reason )
    {
        Log( _TEXT( "Camera list changed. A camera was disconnected from Vimba." ) );
        if( true == m_bIsStreaming )
        {
            OnBnClickedButtonStartstop();
        }
        bUpdateList = true;
    }

    if( true == bUpdateList )
    {
        UpdateCameraListBox();
    }

    m_ButtonStartStop.EnableWindow( 0 < m_cameras.size() || m_bIsStreaming );

    return 0;
}

//
// Copies the content of a byte buffer to a MFC image with respect to the image's alignment
//
// Parameters:
//  [in]    pInbuffer       The byte buffer as received from the cam
//  [in]    ePixelFormat    The pixel format of the frame
//  [out]   OutImage        The filled MFC image
//
void CVmbAPI_MFCDlg::CopyToImage( VmbUchar_t *pInBuffer, VmbPixelFormat_t ePixelFormat, CImage &OutImage )
{
    const int               nHeight         = m_AVT_Cameras.GetHeight();
    const int               nWidth          = m_AVT_Cameras.GetWidth();
    const int               nStride         = OutImage.GetPitch();
    const int               nBitsPerPixel   = OutImage.GetBPP();
    VmbError_t              Result;
    if( ( nWidth*nBitsPerPixel ) /8 != nStride )
    {
        Log( _TEXT( "Vimba only supports stride that is equal to width." ), VmbErrorWrongType );
        return;
    }
    VmbImage                SourceImage,DestinationImage;
    SourceImage.Size        = sizeof( SourceImage );
    DestinationImage.Size   = sizeof( DestinationImage );

    SourceImage.Data        = pInBuffer;
    DestinationImage.Data   = OutImage.GetBits();

    Result = VmbSetImageInfoFromPixelFormat( ePixelFormat, nWidth, nHeight, &SourceImage );
    if( VmbErrorSuccess != Result )
    {
        Log( _TEXT( "Error setting source image info." ), static_cast<VmbErrorType>( Result ) );
        return;
    }
    static const std::string DisplayFormat( "BGR24" );
    Result = VmbSetImageInfoFromString( DisplayFormat.c_str(),DisplayFormat.size(), nWidth,nHeight, &DestinationImage );
    if( VmbErrorSuccess != Result )
    {
        Log( _TEXT( "Error setting destination image info." ),static_cast<VmbErrorType>( Result ) );
        return;
    }
    Result = VmbImageTransform( &SourceImage, &DestinationImage,NULL,0 );
    if( VmbErrorSuccess != Result )
    {
        Log( _TEXT( "Error transforming image." ), static_cast<VmbErrorType>( Result ) );
    }
}

//
// Queries and lists all known camera
//
void CVmbAPI_MFCDlg::UpdateCameraListBox()
{
    // Get all cameras currently connected to Vimba
    CameraPtrVector cameras = m_AVT_Cameras.GetCameraList();

    // Simply forget about all cameras known so far
    m_ListBoxCameras.ResetContent();
    m_cameras.clear();

    // And query the camera details again
    for(    CameraPtrVector::const_iterator iter = cameras.begin();
            cameras.end() != iter;
            ++iter )
    {
        std::string strCameraName;
        std::string strCameraID;
        if( VmbErrorSuccess != (*iter)->GetName( strCameraName ) )
        {
            strCameraName = "[NoName]";
        }
        // If for any reason we cannot get the ID of a camera we skip it
        if( VmbErrorSuccess == (*iter)->GetID( strCameraID ) )
        {
            
            std::string strInfo = strCameraName + " " + strCameraID;
            m_ListBoxCameras.AddString( CString( strInfo.c_str() ) );
            m_cameras.push_back( strCameraID );
        }
        else
        {
            Log( _TEXT("Could not get camera ID") );
        }
    }

    // Select first cam if none is selected
    if (    -1 == m_ListBoxCameras.GetCurSel()
         && 0 < m_cameras.size() )
    {
        m_ListBoxCameras.SetCurSel( 0 );
    }

    m_ButtonStartStop.EnableWindow( 0 < m_cameras.size() || m_bIsStreaming );
}

//
// Prints out a given logging string, error code and the descriptive representation of that error code
//
// Parameters:
//  [in]    strMsg          A given message to be printed out
//  [in]    eErr            The API status code
//
void CVmbAPI_MFCDlg::Log( string_type strMsg, VmbErrorType eErr )
{
    strMsg += _TEXT( "..." ) + m_AVT_Cameras.ErrorCodeToMessage( eErr );
    m_ListLog.InsertString( 0, strMsg.c_str() );
}

//
// Prints out a given logging string
//
// Parameters:
//  [in]    strMsg          A given message to be printed out
//
void CVmbAPI_MFCDlg::Log( string_type strMsg )
{
    m_ListLog.InsertString( 0, strMsg.c_str() );
}

