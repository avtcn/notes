
// VmbAPI_MFCDlg.h : ͷ�ļ�
//

#pragma once

//#include "AVT_Cameras.h"//����AVT����������ͷ�ļ�
#include "ApiController.h"
#include "afxwin.h"


using AVT::VmbAPI::Examples::ApiController;

// CVmbAPI_MFCDlg �Ի���

class CVmbAPI_MFCDlg : public CDialogEx
{
// ����
public:
	CVmbAPI_MFCDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_VMBAPI_MFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

private:

	//AVT_Cameras m_AVT_Cameras;//ʵ����һ��AVT���������
	ApiController m_AVT_Cameras;

	std::vector<std::string> m_cameras;
    // Are we streaming?
    bool m_bIsStreaming;
    // Our MFC image to display
    CImage m_Image;
    // on first call we clear back
    bool m_ClearBackground;
  
    void UpdateCameraListBox();
      
    void Log( string_type strMsg, VmbErrorType eErr );
      
    void Log( string_type strMsg);
       
    void CopyToImage( VmbUchar_t *pInBuffer, VmbPixelFormat_t PixelFormat, CImage &pOutImage );
// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);//�ر�ʱ�ͷ�Vimba����
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	
    afx_msg LRESULT OnFrameReady( WPARAM status, LPARAM lParam );//֡���ջص�
    
    afx_msg LRESULT OnCameraListChanged( WPARAM reason, LPARAM lParam );//

public:
	CStatic m_PictureBoxStream;
	CButton m_ButtonStartStop;
	CListBox m_ListBoxCameras;
	CListBox m_ListLog;
	afx_msg void OnBnClickedButtonStartstop();
};
