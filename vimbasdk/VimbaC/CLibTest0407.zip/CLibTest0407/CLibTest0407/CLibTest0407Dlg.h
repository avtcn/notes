
// CLibTest0407Dlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"


// CCLibTest0407Dlg �Ի���
class CCLibTest0407Dlg : public CDialogEx
{
// ����
public:
	CCLibTest0407Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_CLIBTEST0407_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
	bool m_ClearBackground;

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonRelease();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButtonGraponce();
	CStatic m_PictureBoxStream;
};
