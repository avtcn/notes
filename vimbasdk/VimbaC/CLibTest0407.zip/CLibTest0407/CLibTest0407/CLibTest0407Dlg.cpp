﻿
// CLibTest0407Dlg.cpp : 实现文件
//



#include "stdafx.h"
#include "CLibTest0407.h"
#include "CLibTest0407Dlg.h"
#include "afxdialogex.h"

#include <string>


#include "VimbaC.h"
#include "VmbCommonTypes.h"

#include <atlimage.h>
#pragma comment(lib,"lib\\VimbaC.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#endif



//公共变量
const char* pCameraID;
VmbHandle_t         cameraHandle        = NULL;
const char*         pPixelFormat        = NULL;             // The pixel format we use for acquisition
VmbInt64_t ImageWidth = 0;
VmbInt64_t ImageHeight = 0;
CImage m_Image;
#define NUM_COLORS 3
#define BIT_DEPTH 8


// CCLibTest0407Dlg 对话框
CCLibTest0407Dlg::CCLibTest0407Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CCLibTest0407Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCLibTest0407Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PICTURE_STREAM, m_PictureBoxStream);
}

BEGIN_MESSAGE_MAP(CCLibTest0407Dlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_INIT, &CCLibTest0407Dlg::OnBnClickedButtonInit)
	ON_BN_CLICKED(IDC_BUTTON_RELEASE, &CCLibTest0407Dlg::OnBnClickedButtonRelease)
	ON_BN_CLICKED(IDC_BUTTON_GRAPONCE, &CCLibTest0407Dlg::OnBnClickedButtonGraponce)
END_MESSAGE_MAP()


// CCLibTest0407Dlg 消息处理程序

BOOL CCLibTest0407Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

template <typename T>
CRect fitRect( T w, T h, const CRect &dst)
{
    double sw = static_cast<double>( dst.Width() ) / w;
    double sh = static_cast<double>( dst.Height() ) / h;
    double s = min( sw, sh );
    T new_w = static_cast<T>( w * s );
    T new_h = static_cast<T>( h * s );
    T off_w = (1 + dst.Width() - new_w) /2;
    T off_h = (1 + dst.Height() - new_h) /2;
    return CRect(off_w,off_h, off_w + new_w, off_h + new_h );
}

void CCLibTest0407Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
		if( NULL != m_Image )
        {
            CPaintDC dc( &m_PictureBoxStream );
            CRect rect;
            m_PictureBoxStream.GetClientRect( &rect );
            if( m_ClearBackground)
            {
                m_ClearBackground = false;
                CBrush clearBrush( GetSysColor( COLOR_BTNFACE) );
                dc.FillRect( rect, &clearBrush);
            }
            rect = fitRect( m_Image.GetWidth(), m_Image.GetHeight(), rect );
            // HALFTONE enhances image quality but decreases performance
            dc.SetStretchBltMode( HALFTONE );
            m_Image.StretchBlt( dc.m_hDC, rect );
        }
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CCLibTest0407Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CCLibTest0407Dlg::OnBnClickedButtonInit()
{
	VmbError_t err;
	VmbUint32_t         camCount = 0;
	VmbUint32_t         nFoundCount = 0;
	VmbCameraInfo_t     *pCameras           = NULL;
	VmbAccessMode_t     cameraAccessMode    = VmbAccessModeFull;// We open the camera with full access
    // VmbHandle_t         cameraHandle        = NULL;             // A handle to our camera
    VmbBool_t           bIsCommandDone      = VmbBoolFalse;     // Has a command finished execution
	//const char* pCameraID;

	err = VmbStartup();  //Startup System
	if (err != VmbErrorSuccess)
        return;

	err = VmbFeatureCommandRun(gVimbaHandle, "GeVDiscoveryAllOnce");
	if (err != VmbErrorSuccess) 
		return;

	err = VmbCamerasList(NULL, 0, &camCount, sizeof *pCameras); //Retrieve a list of all cameras.
	if (err != VmbErrorSuccess) 
		return;

	pCameras = (VmbCameraInfo_t*)malloc( camCount * sizeof( *pCameras ));

	if( camCount != 0)
    {   
		err = VmbCamerasList( pCameras, camCount, &nFoundCount, sizeof *pCameras );
		if( nFoundCount != 0 && err == VmbErrorSuccess)
        pCameraID = pCameras[0].cameraIdString;		 
    }
    else
    {
        pCameraID = NULL;
        err = VmbErrorNotFound;
        //printf( "Camera lost.\n" );
    }
	 free( pCameras );
     pCameras = NULL;

	  if ( NULL != pCameraID )//打开相机
        {
            // Open camera
            err = VmbCameraOpen( pCameraID, cameraAccessMode, &cameraHandle );
            if ( VmbErrorSuccess == err )
            {
                // printf( "Camera ID: %s\n\n", pCameraID );
                // Set the GeV packet size to the highest possible value
                // (In this example we do not test whether this cam actually is a GigE cam)
                if ( VmbErrorSuccess == VmbFeatureCommandRun( cameraHandle, "GVSPAdjustPacketSize" ))
                {
                    do
                    {
                        if ( VmbErrorSuccess != VmbFeatureCommandIsDone(cameraHandle,"GVSPAdjustPacketSize",&bIsCommandDone ))
                        {
                            break;
                        }
                    } while ( VmbBoolFalse == bIsCommandDone );
                }
			}

			err = VmbFeatureEnumSet( cameraHandle, "PixelFormat", "BGR8Packed" );
        
			 if ( VmbErrorSuccess != err )
			{
				// Fall back to Mono
				err = VmbFeatureEnumSet( cameraHandle, "PixelFormat", "Mono8" );
			}
			// Read back pixel format
			err = VmbFeatureEnumGet( cameraHandle, "PixelFormat", &pPixelFormat );
			if (err != VmbErrorSuccess) 
				return;
			err = VmbFeatureIntGet( cameraHandle, "Height", &ImageHeight );
			err = VmbFeatureIntGet( cameraHandle, "Width", &ImageWidth );

			m_Image.Create(  ImageWidth,ImageHeight,NUM_COLORS * BIT_DEPTH );
			m_ClearBackground = true;

	  }
	
}


void CCLibTest0407Dlg::OnBnClickedButtonRelease()
{
	VmbError_t err;
	err = VmbCameraClose ( cameraHandle );
	VmbShutdown();
	m_Image.Destroy();
	cameraHandle = NULL; 
	pCameraID = NULL;
	
}

void inline BufferToCImage( VmbUchar_t *pInBuffer, CImage& OutImage )
{
			
	int nHeight = ImageHeight;
	int nWidth  = ImageWidth;
	
	//重建cimage
	OutImage.Destroy();
	OutImage.Create(nWidth, nHeight, 8 * NUM_COLORS);
 
	VmbUchar_t* pucRow= pInBuffer;									//指向数据区的行指针
	VmbUchar_t* pucImage = (VmbUchar_t*)OutImage.GetBits();	            //指向数据区的指针
	int nStep1 = nWidth*NUM_COLORS;
	int nStep = OutImage.GetPitch();					        //每行的字节数,注意这个返回值有正有负
 
	if (1 == NUM_COLORS)								//对于单通道的图像需要初始化调色板
	{
		RGBQUAD* rgbquadColorTable;
		int nMaxColors = 256;
		rgbquadColorTable = new RGBQUAD[nMaxColors];
		OutImage.GetColorTable(0, nMaxColors, rgbquadColorTable);
		for (int nColor = 0; nColor < nMaxColors; nColor++)
		{
			rgbquadColorTable[nColor].rgbBlue = (VmbUchar_t)nColor;
			rgbquadColorTable[nColor].rgbGreen = (VmbUchar_t)nColor;
			rgbquadColorTable[nColor].rgbRed = (VmbUchar_t)nColor;
		}
		OutImage.SetColorTable(0, nMaxColors, rgbquadColorTable);
		delete []rgbquadColorTable;
	}
	//memcpy(pucImage, pInBuffer, nStep * nHeight );
       //拷贝数据
	for (int nRow = 0; nRow < nHeight; nRow++)
	{		
		for (int nCol = 0; nCol < nWidth; nCol++)
		{			
			if (1 == NUM_COLORS)
			{
				*(pucRow + nRow * nStep + nCol) = *(pucImage + nRow * nStep1 + nCol);
			}
			else if (3 == NUM_COLORS)
			{
				for (int nCha = 0 ; nCha < 3; nCha++)
				{
					*(pucImage + nRow * nStep + nCol * 3 + nCha) = *(pucRow + nRow * nStep1 + nCol * 3 + nCha);
				}			
			}
		}	
	}
}


void CCLibTest0407Dlg::OnBnClickedButtonGraponce()
{
	VmbError_t err;
	VmbFrame_t          frame;                                  // The frame we capture
    
    VmbInt64_t          nPayloadSize        = 0;      
	

    if ( cameraHandle != NULL )
    {

        // Evaluate frame size
        err = VmbFeatureIntGet( cameraHandle, "PayloadSize", &nPayloadSize );

        if ( VmbErrorSuccess == err )
        {
            frame.buffer        = (unsigned char*)malloc( (VmbUint32_t)nPayloadSize );
            frame.bufferSize    = (VmbUint32_t)nPayloadSize;

            // Announce Frame
            err = VmbFrameAnnounce( cameraHandle, &frame, (VmbUint32_t)sizeof( VmbFrame_t ));
            if ( VmbErrorSuccess == err )
            {
                // Start Capture Engine
                err = VmbCaptureStart( cameraHandle );
                if ( VmbErrorSuccess == err )
                {
                    // Queue Frame
                    err = VmbCaptureFrameQueue( cameraHandle, &frame, NULL );
                    if ( VmbErrorSuccess == err )
                    {
                        // Start Acquisition
                        err = VmbFeatureCommandRun( cameraHandle,"AcquisitionStart" );
                        if ( VmbErrorSuccess == err )
                        {
                            // Capture one frame synchronously
                            err = VmbCaptureFrameWait( cameraHandle, &frame, 5000 );
                            if ( VmbErrorSuccess == err )
                            {
                                // Convert the captured frame to a bitmap and save to disk
                                if ( VmbFrameStatusComplete == frame.receiveStatus )
                                {
									VmbUchar_t *pBuffer=(VmbUchar_t*) frame.buffer;
									

                                    BufferToCImage(pBuffer,m_Image );

									RECT rect;
									m_PictureBoxStream.GetWindowRect( &rect );
									ScreenToClient( &rect );
									InvalidateRect( &rect, false );
                                                                                                                                 
                                }
                                
                            }                           
                            // Stop Acquisition
                            err = VmbFeatureCommandRun( cameraHandle,"AcquisitionStop" );                                            
                        }                       
                    }                   
                    // Stop Capture Engine
                    err = VmbCaptureEnd( cameraHandle );                                    
                }              
                // Revoke frame
                err = VmbFrameRevoke( cameraHandle, &frame );                                
            }          
            free( frame.buffer );
            frame.buffer = NULL;
        }
    }
}
