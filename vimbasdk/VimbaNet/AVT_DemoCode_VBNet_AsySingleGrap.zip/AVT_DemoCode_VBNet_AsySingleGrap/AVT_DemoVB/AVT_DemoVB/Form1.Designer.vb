﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.tB_Log = New System.Windows.Forms.TextBox()
        Me.Bt_Open = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Bt_AquireSingle = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Bt_AquireSingle2 = New System.Windows.Forms.Button()
        Me.Bt_Open2 = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(6, 19)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(432, 305)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'tB_Log
        '
        Me.tB_Log.Location = New System.Drawing.Point(1, 395)
        Me.tB_Log.Multiline = True
        Me.tB_Log.Name = "tB_Log"
        Me.tB_Log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tB_Log.Size = New System.Drawing.Size(886, 313)
        Me.tB_Log.TabIndex = 1
        '
        'Bt_Open
        '
        Me.Bt_Open.Location = New System.Drawing.Point(6, 338)
        Me.Bt_Open.Name = "Bt_Open"
        Me.Bt_Open.Size = New System.Drawing.Size(103, 36)
        Me.Bt_Open.TabIndex = 3
        Me.Bt_Open.Text = "打开相机"
        Me.Bt_Open.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Bt_AquireSingle)
        Me.GroupBox1.Controls.Add(Me.Bt_Open)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(1, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(444, 387)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Camera1"
        '
        'Bt_AquireSingle
        '
        Me.Bt_AquireSingle.Location = New System.Drawing.Point(182, 345)
        Me.Bt_AquireSingle.Name = "Bt_AquireSingle"
        Me.Bt_AquireSingle.Size = New System.Drawing.Size(75, 23)
        Me.Bt_AquireSingle.TabIndex = 0
        Me.Bt_AquireSingle.Text = "单张采图"
        Me.Bt_AquireSingle.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Bt_AquireSingle2)
        Me.GroupBox2.Controls.Add(Me.Bt_Open2)
        Me.GroupBox2.Controls.Add(Me.PictureBox2)
        Me.GroupBox2.Location = New System.Drawing.Point(451, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(435, 387)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Camera2"
        '
        'Bt_AquireSingle2
        '
        Me.Bt_AquireSingle2.Location = New System.Drawing.Point(154, 345)
        Me.Bt_AquireSingle2.Name = "Bt_AquireSingle2"
        Me.Bt_AquireSingle2.Size = New System.Drawing.Size(75, 23)
        Me.Bt_AquireSingle2.TabIndex = 0
        Me.Bt_AquireSingle2.Text = "单张采图"
        Me.Bt_AquireSingle2.UseVisualStyleBackColor = True
        '
        'Bt_Open2
        '
        Me.Bt_Open2.Location = New System.Drawing.Point(6, 338)
        Me.Bt_Open2.Name = "Bt_Open2"
        Me.Bt_Open2.Size = New System.Drawing.Size(103, 36)
        Me.Bt_Open2.TabIndex = 3
        Me.Bt_Open2.Text = "打开相机"
        Me.Bt_Open2.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(6, 19)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(422, 305)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(896, 708)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tB_Log)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents tB_Log As System.Windows.Forms.TextBox
    Friend WithEvents Bt_Open As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Bt_AquireSingle As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Bt_AquireSingle2 As System.Windows.Forms.Button
    Friend WithEvents Bt_Open2 As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox

End Class
