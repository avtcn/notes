﻿
Imports avt.VmbAPINET
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Threading
'Demo说明

'通过异步软触发的方式实现同步采集
'支持2个相机（可扩展至多相机）

'为了便于理解，简化了官方例程的一些函数
'如果需要相机的动态列表或更多功能，可以参考官方自带的例程，比如AsynchronousGrab

Public Class Form1
    Dim myVimba As New Vimba
    Dim camera1, camera2 As New AVTcamera

    Private Sub LogMessage(ByVal message As String)        
        tB_Log.AppendText(String.Format("{0:yyyy-MM-dd HH:mm:ss.ffff}: {1}", DateTime.Now, message) + vbCrLf)
    End Sub

    Private Sub InitCameras()

        Try           
            camera1.m_Cam = myVimba.GetCameraByID("192.168.20.12") '两种方式都可以
            'Camera1.m_Cam = m_Vimba.GetCameraByID("DEV_000F314D95AE")           
            Bt_Open.Enabled = True
            LogMessage("相机1初始化成功")
        Catch

            Bt_Open.Enabled = False
            LogMessage("相机1初始化失败")

        End Try

        Try
            camera2.m_Cam = myVimba.GetCameraByID("192.168.4.66") '两种方式都可以
            'Camera1.m_Cam = m_Vimba.GetCameraByID("DEV_000F314D95AE")           
            Bt_Open2.Enabled = True
            LogMessage("相机2初始化成功")
        Catch

            Bt_Open2.Enabled = False
            LogMessage("相机2初始化失败")

        End Try

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        myVimba.Startup()
        InitCameras()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        myVimba.Shutdown()
        myVimba = Nothing

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_Open.Click
        If camera1.IsOpen Then
            Try
                camera1.CloseCamera()
                Bt_Open.Text = "打开相机"
                Bt_Open.Enabled = False               
            Catch               
            End Try

        Else
            Try
                camera1.OpenCamera()
                Bt_Open.Text = "关闭相机"
                Bt_Open.Enabled = True               
            Catch                
            End Try
        End If

    End Sub
    Private Sub Bt_Open2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_Open2.Click
        If camera2.IsOpen Then
            Try
                camera2.CloseCamera()
                Bt_Open2.Text = "打开相机"
                Bt_AquireSingle.Enabled = False
            Catch
            End Try
        Else
            Try
                camera2.OpenCamera()
                Bt_Open2.Text = "关闭相机"
                Bt_AquireSingle.Enabled = True
            Catch
            End Try
        End If

    End Sub

    Private Sub acqTest1()
        For i = 0 To 50
            System.Threading.Thread.Sleep(20)
            PictureBox1.Image = camera1.AcquireSingleImage(1000)
            Application.DoEvents()
        Next
    End Sub

    Private Sub acqTest2()
        For i = 0 To 50
            System.Threading.Thread.Sleep(2000)
            PictureBox2.Image = camera2.AcquireSingleImage(1000)
            Application.DoEvents()
        Next
    End Sub
    Private Sub Bt_AquireSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_AquireSingle.Click
        'Dim th1 As Thread
        'th1 = New Thread(New ThreadStart(AddressOf acqTest1))
        'th1.Start()
        PictureBox1.Image = camera1.AcquireSingleImage(1000)
       
    End Sub
    Private Sub Bt_AquireSingle2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_AquireSingle2.Click
        'Dim th2 As Thread
        'th2 = New Thread(New ThreadStart(AddressOf acqTest2))
        'th2.Start()
        PictureBox2.Image = camera2.AcquireSingleImage(1000)
    End Sub
   
End Class
