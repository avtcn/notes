﻿Imports avt.VmbAPINET
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Threading

Public Class AVTcamera

    Public m_Cam As Camera
    Private m_frame As Frame = Nothing
    Private sem As Semaphore = New Semaphore(0, 1)

    Public Property IsOpen() As Boolean
    Public Property IsAcquring() As Boolean

    Sub New()

        IsOpen = False
        IsAcquring = False
        m_Cam = Nothing
       
    End Sub

    Public Function OpenCamera() As Boolean

        Try
            m_Cam.Open(VmbAccessModeType.VmbAccessModeFull)
            If m_Cam.InterfaceType = VmbInterfaceType.VmbInterfaceEthernet Then
                m_Cam.Features("GVSPAdjustPacketSize").RunCommand()
                While (False = m_Cam.Features("GVSPAdjustPacketSize").IsCommandDone())
                    'Do Nothing
                End While
            End If

            AdjustPixelFormat(m_Cam) '可用可不用
            Set_TriggerSource(3) '设置为软触发
            StartContinousAcquisition() '开始采集

            IsOpen = True

            Return IsOpen
        Catch
            Return False
        End Try

    End Function

    Public Sub CloseCamera()

        Try
            If IsAcquring = True Then '实际上直接关闭相机也可以
                StopContinousAcquisition()
            End If
            m_Cam.Close()
            IsOpen = False
            IsAcquring = False

        Catch
        End Try

    End Sub

    Public Sub Set_TriggerSource(ByVal Tri_index As Integer)

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        Select Case (Tri_index)
            Case 1
                m_Cam.Features("TriggerSource").EnumValue = "Freerun"
            Case 2
                m_Cam.Features("TriggerSource").EnumValue = "Line1"
            Case 3
                m_Cam.Features("TriggerSource").EnumValue = "Software"

        End Select
        m_Cam.Features("AcquisitionMode").EnumValue = "Continuous"
        m_Cam.Features("TriggerMode").EnumValue = "On"

    End Sub

    Public Sub SendSoftwareTrigger()
        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        m_Cam.Features("TriggerSoftware").RunCommand()
        While False = m_Cam.Features("TriggerSoftware").IsCommandDone()
            'Do nothing
        End While


    End Sub

    Public Sub Set_ExposureTime(ByVal time As Double)

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        If m_Cam.Features.ContainsName("ExposureTimeAbs") Then
            m_Cam.Features("ExposureTimeAbs").FloatValue = time
        Else
            m_Cam.Features("ExposureTime").FloatValue = time 'Goldeye/USB系列用的FeatureName是这个,具体参数名以Vimba Viwer软件打开对应相机后显示的为准
        End If


    End Sub

    Public Function ReadExposureTime() As Double

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        If m_Cam.Features.ContainsName("ExposureTimeAbs") Then
            Return m_Cam.Features("ExposureTimeAbs").FloatValue
        Else
            Return m_Cam.Features("ExposureTime").FloatValue
        End If
       
    End Function

    Public Sub StartContinousAcquisition() '停止连续采集

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If
        Try
            AddHandler m_Cam.OnFrameReceived, AddressOf m_CamOnFrameReceived '//注册图像接收事件
            m_Cam.StartContinuousImageAcquisition(3)
            'm_Cam.Features["AcquisitionStart"].RunCommand();//作用和上一句相同，但是标准写法是这一句
            IsAcquring = True
        Catch
        End Try

    End Sub
  

    Public Sub StopContinousAcquisition() '停止连续采集

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If
        Try
            RemoveHandler m_Cam.OnFrameReceived, AddressOf m_CamOnFrameReceived '//注销图像接收事件
            m_Cam.StopContinuousImageAcquisition()
            'm_Cam.Features["AcquisitionStop"].RunCommand();//作用和上一句相同，但是标准写法是这一句
            IsAcquring = False
        Catch
        End Try
       
    End Sub

    Private Sub m_CamOnFrameReceived(ByVal frame As Frame)

        If VmbFrameStatusType.VmbFrameStatusComplete = frame.ReceiveStatus Then
            
            m_frame = frame
            sem.Release()
            
        End If

        Try
            m_Cam.QueueFrame(frame)
        Catch
            'System.Diagnostics.Debug.WriteLine("camera " + index + ":  name is " + m_Camera.Name + ", model is " + m_Camera.Model);
        End Try
    End Sub

    Public Function AcquireSingleImage(ByVal timeout As Integer) As Bitmap

        Dim frame As Frame = Nothing
        Dim btmap As Bitmap = Nothing

        SendSoftwareTrigger()
        If (sem.WaitOne(timeout)) Then
            btmap = ConvertFrame(m_frame)
            Return btmap
        Else
            System.Diagnostics.Debug.WriteLine(m_Cam.Id.ToString() + "timeout")
            Return Nothing
        End If
    End Function
    Private Function ConvertFrame(ByVal frame As Frame) As Bitmap

        Dim MyBmp As Bitmap = Nothing
        If IsNothing(frame) Then
            Throw New ArgumentNullException("frame")
        End If
        'Check if the image is valid
        If (VmbFrameStatusType.VmbFrameStatusComplete <> frame.ReceiveStatus) Then
            Throw New Exception("Invalid frame received. Reason: " + frame.ReceiveStatus.ToString())
        End If

        frame.Fill(MyBmp)
        Return MyBmp

    End Function

  

    Public Sub AdjustPixelFormat(ByVal camera As Camera)

        If IsNothing(camera) Then
            Throw New ArgumentNullException("camera")
        End If

        Dim supportedPixelFormats() As String = {"BGR8Packed", "Mono8"}
        'Check for compatible pixel format
        Dim pixelFormatFeature As Feature = camera.Features("PixelFormat")

        'Determine current pixel format
        Dim currentPixelFormat As String = pixelFormatFeature.EnumValue

        'Check if current pixel format is supported
        Dim currentPixelFormatSupported As Boolean = False
        For Each supportedPixelFormat As String In supportedPixelFormats

            If String.Compare(currentPixelFormat, supportedPixelFormat, StringComparison.Ordinal) = 0 Then
                currentPixelFormatSupported = True
                Exit For

            End If
        Next

        'Only adjust pixel format if we not already have a compatible one.
        If currentPixelFormatSupported = False Then
            'Determine available pixel formats
            Dim availablePixelFormats() As String = pixelFormatFeature.EnumValues
            'Check if there is a supported pixel format
            Dim pixelFormatSet As Boolean = False

            For Each supportedPixelFormat As String In supportedPixelFormats
                For Each availablePixelFormat As String In availablePixelFormats
                    If (String.Compare(supportedPixelFormat, availablePixelFormat, StringComparison.Ordinal) = 0) And (pixelFormatFeature.IsEnumValueAvailable(supportedPixelFormat) = True) Then
                        'Set the found pixel format
                        pixelFormatFeature.EnumValue = supportedPixelFormat
                        pixelFormatSet = True
                        Exit For
                    End If
                Next

                If True = pixelFormatSet Then
                    Exit For
                End If
            Next

            If False = pixelFormatSet Then
                Throw New Exception("None of the pixel formats that are supported by this example (Mono8 and BRG8Packed) can be set in the camera.")
            End If

        End If
    End Sub



End Class
