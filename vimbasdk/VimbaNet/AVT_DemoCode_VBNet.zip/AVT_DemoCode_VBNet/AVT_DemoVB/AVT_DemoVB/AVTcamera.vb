﻿Imports avt.VmbAPINET
Imports System.Drawing
Imports System.Drawing.Imaging

Public Delegate Sub ImageReceivedHandler(ByVal bmp As Bitmap)
Public Class AVTcamera

    '常规相机不需要
    Private Const m_RingBitmapSize As Integer = 2
    Private ReadOnly m_ImageInUseSyncLock As Object = New Object()
    Private m_RingBitmap As RingBitmap = Nothing
    Private m_ImageInUse As Boolean = True
    '常规相机不需要

    Private ImageHandler As ImageReceivedHandler = Nothing
    Public m_Cam As Camera

    'Private _IsOpen As Boolean = False   
    Public Property IsOpen() As Boolean
    '    Get
    '        IsOpen = _IsOpen
    '    End Get
    '    Set(ByVal value As Boolean)
    '        _IsOpen = value
    '    End Set
    'End Property

    Public Property IsAcquring() As Boolean

    Public Property ImageInUse() As Boolean

        Get
            SyncLock (m_ImageInUseSyncLock)
                ImageInUse = m_ImageInUse
            End SyncLock
        End Get

        Set(ByVal value As Boolean)
            SyncLock (m_ImageInUseSyncLock)
                m_ImageInUse = value
            End SyncLock
        End Set
    End Property

    Sub New()

        IsOpen = False
        IsAcquring = False
        m_Cam = Nothing
        m_RingBitmap = New RingBitmap(m_RingBitmapSize)

    End Sub


    Public Function OpenCamera() As Boolean

        Try
            m_Cam.Open(VmbAccessModeType.VmbAccessModeFull)
            If m_Cam.InterfaceType = VmbInterfaceType.VmbInterfaceEthernet Then
                m_Cam.Features("GVSPAdjustPacketSize").RunCommand()
                While (False = m_Cam.Features("GVSPAdjustPacketSize").IsCommandDone())
                    'Do Nothing
                End While
            End If

            AdjustPixelFormat(m_Cam) '可用可不用
            IsOpen = True
            ' IsAcquring = False
            Return True
        Catch
            Return False
        End Try

    End Function

    Public Sub CloseCamera()

        Try
            If IsAcquring = True Then '实际上直接关闭相机也可以
                StopContinousAcquisition()
            End If
            m_Cam.Close()
            IsOpen = False
            IsAcquring = False

        Catch
        End Try

    End Sub

    Public Sub Set_TriggerSource(ByVal Tri_index As Integer)

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        Select Case (Tri_index)
            Case 1
                m_Cam.Features("TriggerSource").EnumValue = "Freerun"
            Case 2
                m_Cam.Features("TriggerSource").EnumValue = "Line1"
            Case 3
                m_Cam.Features("TriggerSource").EnumValue = "Software"

        End Select
        m_Cam.Features("TriggerMode").EnumValue = "On"
    End Sub

    Public Sub SendSoftwareTrigger()
        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        m_Cam.Features("TriggerSoftware").RunCommand()
        While False = m_Cam.Features("TriggerSoftware").IsCommandDone()
            'Do nothing
        End While


    End Sub

    Public Sub Set_ExposureTime(ByVal time As Double)

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        If m_Cam.Features.ContainsName("ExposureTimeAbs") Then
            m_Cam.Features("ExposureTimeAbs").FloatValue = time
        Else
            m_Cam.Features("ExposureTime").FloatValue = time 'Goldeye/USB系列用的FeatureName是这个,具体参数名以Vimba Viwer软件打开对应相机后显示的为准
        End If


    End Sub

    Public Function ReadExposureTime() As Double

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        If m_Cam.Features.ContainsName("ExposureTimeAbs") Then
            Return m_Cam.Features("ExposureTimeAbs").FloatValue
        Else
            Return m_Cam.Features("ExposureTime").FloatValue
        End If
       
    End Function

    Public Sub StartContinousAcquisition(ByVal ImageReceived As ImageReceivedHandler) '开始连续采集

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If

        ' m_RingBitmap = New RingBitmap(m_RingBitmapSize)
        m_ImageInUse = True

        ImageHandler = ImageReceived
        Try
            AddHandler m_Cam.OnFrameReceived, AddressOf m_CamOnFrameReceived '//注册图像接收事件
            m_Cam.StartContinuousImageAcquisition(3)
            'm_Cam.Features["AcquisitionStart"].RunCommand();//作用和上一句相同，但是标准写法是这一句
            IsAcquring = True
        Catch
        End Try
    End Sub

    Public Sub StopContinousAcquisition() '停止连续采集

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If
        Try
            RemoveHandler m_Cam.OnFrameReceived, AddressOf m_CamOnFrameReceived '//注销图像接收事件
            m_Cam.StopContinuousImageAcquisition()
            'm_Cam.Features["AcquisitionStop"].RunCommand();//作用和上一句相同，但是标准写法是这一句
            IsAcquring = False
        Catch
        End Try
       
    End Sub

    Private Sub m_CamOnFrameReceived(ByVal frame As Frame)

        If VmbFrameStatusType.VmbFrameStatusComplete = frame.ReceiveStatus Then
            Dim bmp As Bitmap = Nothing
            bmp = ConvertFrame(frame)

            If Not (IsNothing(ImageHandler) Or IsNothing(bmp)) Then
                ImageHandler(bmp)
            End If
        End If

        Try
            m_Cam.QueueFrame(frame)
        Catch
            'System.Diagnostics.Debug.WriteLine("camera " + index + ":  name is " + m_Camera.Name + ", model is " + m_Camera.Model);
        End Try
    End Sub

    Public Function AcquireSingleImage() As Bitmap

        If IsNothing(m_Cam) Then
            Throw New NullReferenceException("No camera retrieved.")
        End If
        Dim frame As Frame = Nothing
        Try
            m_Cam.AcquireSingleImage(frame, 2000)
            Return ConvertFrame(frame)
        Catch
            Return Nothing
        End Try

    End Function
    Private Function ConvertFrame1(ByVal frame As Frame) As Bitmap

        Dim MyBmp As Bitmap = Nothing
        If IsNothing(frame) Then
            Throw New ArgumentNullException("frame")
        End If
            'Check if the image is valid
        If (VmbFrameStatusType.VmbFrameStatusComplete <> frame.ReceiveStatus) Then
            Throw New Exception("Invalid frame received. Reason: " + frame.ReceiveStatus.ToString())
        End If
           
        If (ImageInUse) Then

            ' Convert raw frame data into image (for image display)
            m_RingBitmap.FillNextBitmap(frame)
            MyBmp = m_RingBitmap.m_Image
            ImageInUse = False

        End If
        Return MyBmp

    End Function

    Public Function ConvertFrame(ByVal frame As Frame) As Bitmap
        Dim MyBmp As Bitmap = Nothing
        If IsNothing(frame) Then
            Throw New ArgumentNullException("frame")
        End If

        'Check if the image is valid
        If (VmbFrameStatusType.VmbFrameStatusComplete <> frame.ReceiveStatus) Then
            Throw New Exception("Invalid frame received. Reason: " + frame.ReceiveStatus.ToString())
        End If

        'Convert raw frame data into image (for image display)
        Dim btmp As Bitmap = Nothing
        Select Case frame.PixelFormat

            Case VmbPixelFormatType.VmbPixelFormatMono8



                btmp = New Bitmap(Int(frame.Width), Int(frame.Height), PixelFormat.Format8bppIndexed)

                'Set greyscale palette
                Dim palette As ColorPalette = btmp.Palette
                For i = 0 To palette.Entries.Length - 1
                    palette.Entries(i) = Color.FromArgb(i, i, i)
                Next
                btmp.Palette = palette

                'Copy image data
                Dim btmpData As BitmapData = btmp.LockBits(New Rectangle(0, 0, Int(frame.Width), Int(frame.Height)), ImageLockMode.WriteOnly, PixelFormat.Format8bppIndexed)
                Try
                    'Copy image data line by line
                    For y = 0 To Int(frame.Height) - 1

                        System.Runtime.InteropServices.Marshal.Copy(frame.Buffer, y * Int(frame.Width), New IntPtr(btmpData.Scan0.ToInt64() + y * btmpData.Stride), Int(frame.Width))

                    Next

                Finally

                    btmp.UnlockBits(btmpData)
                    MyBmp = btmp
                End Try

            Case VmbPixelFormatType.VmbPixelFormatBgr8

                btmp = New Bitmap(Int(frame.Width), Int(frame.Height), PixelFormat.Format24bppRgb)


                Dim btmpData As BitmapData = btmp.LockBits(New Rectangle(0, 0, Int(frame.Width), Int(frame.Height)), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb)
                Try

                    'Copy image data line by line
                    For y = 0 To Int(frame.Height) - 1

                        System.Runtime.InteropServices.Marshal.Copy(frame.Buffer,
                                                                        y * (Int(frame.Width)) * 3,
                                                                        New IntPtr(btmpData.Scan0.ToInt64() + y * btmpData.Stride),
                                                                        (Int(frame.Width) * 3))
                    Next

                Finally
                    btmp.UnlockBits(btmpData)
                    MyBmp = btmp
                End Try

            Case Else
                frame.Fill(btmp)
                MyBmp = btmp

        End Select
        Return MyBmp
    End Function

    Public Sub AdjustPixelFormat(ByVal camera As Camera)

        If IsNothing(camera) Then
            Throw New ArgumentNullException("camera")
        End If

        Dim supportedPixelFormats() As String = {"BGR8Packed", "Mono8"}
        'Check for compatible pixel format
        Dim pixelFormatFeature As Feature = camera.Features("PixelFormat")

        'Determine current pixel format
        Dim currentPixelFormat As String = pixelFormatFeature.EnumValue

        'Check if current pixel format is supported
        Dim currentPixelFormatSupported As Boolean = False
        For Each supportedPixelFormat As String In supportedPixelFormats

            If String.Compare(currentPixelFormat, supportedPixelFormat, StringComparison.Ordinal) = 0 Then
                currentPixelFormatSupported = True
                Exit For

            End If
        Next

        'Only adjust pixel format if we not already have a compatible one.
        If currentPixelFormatSupported = False Then
            'Determine available pixel formats
            Dim availablePixelFormats() As String = pixelFormatFeature.EnumValues
            'Check if there is a supported pixel format
            Dim pixelFormatSet As Boolean = False

            For Each supportedPixelFormat As String In supportedPixelFormats
                For Each availablePixelFormat As String In availablePixelFormats
                    If (String.Compare(supportedPixelFormat, availablePixelFormat, StringComparison.Ordinal) = 0) And (pixelFormatFeature.IsEnumValueAvailable(supportedPixelFormat) = True) Then
                        'Set the found pixel format
                        pixelFormatFeature.EnumValue = supportedPixelFormat
                        pixelFormatSet = True
                        Exit For
                    End If
                Next

                If True = pixelFormatSet Then
                    Exit For
                End If
            Next

            If False = pixelFormatSet Then
                Throw New Exception("None of the pixel formats that are supported by this example (Mono8 and BRG8Packed) can be set in the camera.")
            End If

        End If
    End Sub



End Class
