﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using AVT.VmbAPINET;
//Demo说明

//支持同步采集、异步采集两种模式
//支持两个相机（可扩展至多相机）

//为了便于理解，简化了官方例程的一些函数
//使用异步的方式连续采集时，可能会出现图片显示闪屏的BUG，如果有建议参考官方自带的AsynchronousGrab例程
namespace CameraViewer1
{
   
    public partial class Form1 : Form
    {
       

        private Vimba m_Vimba = null;
        private AVT_Cam Camera1, Camera2;

        double Cam1_ExpTime = 1500;
        string Cam1_TriggerSource = "Freerun";

        double Cam2_ExpTime = 1500;
        string Cam2_TriggerSource = "Freerun";

        public Form1()
        {
            InitializeComponent();
        }
        private void LogMessage(string message)
        {
            if (null == message)
            {
                throw new ArgumentNullException("message");
            }
            tB_Log.AppendText(string.Format("{0:yyyy-MM-dd HH:mm:ss.fff}: {1}", DateTime.Now, message) + "\r\n");       
        }
      
        //Add an error log message and show an error message box
        private void LogError(string message)
        {
            LogMessage(message);

            MessageBox.Show(message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        private void Init_Camera()
        {
            
            try
            {
                Camera1 = new AVT_Cam();
                Camera1.m_Cam  = m_Vimba.GetCameraByID("192.168.0.12");//两种方式都可以
                //Camera1.m_Cam = m_Vimba.GetCameraByID("DEV_000F314D95AE") ;           
                bT_OpenCamera.Enabled = true;
                LogMessage("相机1初始化成功");
               
            }
            catch
            {
                bT_OpenCamera.Enabled = false;
                LogMessage("相机1初始化失败");
            }
            try
            {
                Camera2 = new AVT_Cam();
                Camera2.m_Cam = m_Vimba.GetCameraByID("192.168.8.103");
                bT_OpenCamera2.Enabled = true;
                LogMessage("相机2初始化成功");                
            }
            catch
            {
                bT_OpenCamera2.Enabled = false;
                LogMessage("相机2初始化失败"); 
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            try 
            {
                Vimba vimba = new Vimba();
                vimba.Startup();
                m_Vimba = vimba;
                Init_Camera();
                updateControls();
                updateControls2();
            }
            catch(Exception exception)
            {
                LogError("Could not startup Vimba API. Reason: " + exception.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (null == m_Vimba)
            {
                throw new Exception("Vimba has not been started.");
            }
            m_Vimba.Shutdown();
            m_Vimba = null;           
        }
            
        private void bT_OpenCamera_Click(object sender, EventArgs e)
        {
            if (!Camera1.IsOpen)
            {
                bool IsOpen= Camera1.OpenCamera();
                if (IsOpen)
               {
                   //-------读取相机参数到界面-----                               
                   Cam1_ExpTime = Camera1.ReadExposureTime();
                   trackBar1.Value = (int)Cam1_ExpTime;

                   Camera1.Set_TriggerSource(1);
                   Cam1_TriggerSource = Camera1.ReadTriggerSource();
                   rBt_Freerun.Checked = true;//触发方式就不反馈到界面了，需要也可以
                   LogMessage("相机1打开成功！");
               }
               else
               {
                   LogMessage("相机1打开失败，请检查IP配置");
               }
 
            }
            else
            {
                Camera1.CloseCamera();
            }

            updateControls();            
                
        }
        private void bT_OpenCamera2_Click(object sender, EventArgs e)
        {
            if (!Camera2.IsOpen)
            {
                Camera2.OpenCamera();
                //Camera1.Set_FreeRun();

                //-------读取相机参数到界面-----                               
                Cam2_ExpTime = Camera2.ReadExposureTime();
                trackBar2.Value = (int)Cam2_ExpTime;

                Camera2.Set_TriggerSource(1);
                Cam2_TriggerSource = Camera2.ReadTriggerSource();
                rBt_Freerun2.Checked = true;//触发方式就不反馈到界面了，需要也可以

            }
            else
            {
                Camera2.CloseCamera();
            }

            updateControls2();  

        }
        private void bT_Acqure_Click(object sender, EventArgs e)
        {
            if (!(Camera1.IsAcquring))
            {
                Camera1.StartAcquisition(mCam1_OnFrameReceived);//委托图像接收
               
                if ((!bT_SendSoftTri.Enabled) && rBt_SoftTri.Checked)
                {
                    bT_SendSoftTri.Enabled = true;
                }
                bT_Acqsingle.Enabled = false;
            }
            else
            {
                Camera1.StopAcquisition();
                bT_SendSoftTri.Enabled = false;//非采集状态下不接收软/硬件触发信号
                bT_Acqsingle.Enabled = true;
            }
            updateControls();
        }
        private void bT_Acqure2_Click(object sender, EventArgs e)
        {
            if (!(Camera2.IsAcquring))
            {
                Camera2.StartAcquisition(mCam2_OnFrameReceived);//委托图像接收
                if ((!bT_SendSoftTri2.Enabled) && rBt_SoftTri2.Checked)
                {
                    bT_SendSoftTri2.Enabled = true;
                }
            }
            else
            {
                Camera2.StopAcquisition();
            }
            updateControls2();

        }
        private void mCam1_OnFrameReceived(Image img)
        {
            if (InvokeRequired == true)
            {
                BeginInvoke(new ImageReceivedHandler(this.mCam1_OnFrameReceived), img);
                return;
            }
            m_PictureBox.Image = img;
           // LogMessage("end");
            //在此处可以对图像处理，帧率比较快的话建议在此处另开线程          
        }
        private void mCam2_OnFrameReceived(Image img)
        {
            if (InvokeRequired == true)
            {
                BeginInvoke(new ImageReceivedHandler(this.mCam2_OnFrameReceived), img);
                return;
            }
            pictureBox1.Image = img;            
        }
       
        private void updateControls()
        {           
            if (Camera1.IsOpen)
            {
                bT_OpenCamera.Text = "关闭相机";
                p_SetCam1.Enabled = true;//任何关于相机的设置都要在相机打开的前提下，设置触发方式或者曝光时间则尽量要在相机停止采集的状态下
               
                if (Camera1.IsAcquring)
                {
                    bT_Acqure.Text = "停止采集/OffLine";

                }
                else
                {
                    bT_Acqure.Text = "开始采集/OnLine";
                }
            }
            else
            {             
                bT_OpenCamera.Text = "打开相机";
                p_SetCam1.Enabled = false;
            }
        }

        private void updateControls2()
        {
            if (Camera2.IsOpen)
            {
                bT_OpenCamera2.Text = "关闭相机";
                p_SetCam2.Enabled = true;//任何关于相机的设置都要在相机打开的前提下，设置触发方式或者曝光时间则尽量要在相机停止采集的状态下

                if (Camera2.IsAcquring)
                {
                    bT_Acqure2.Text = "停止采集/OffLine";
                }
                else
                {
                    bT_Acqure2.Text = "开始采集/OnLine";
                }
            }
            else
            {
                bT_OpenCamera2.Text = "打开相机";
                p_SetCam2.Enabled = false;
            }
        }


        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Cam1_ExpTime = trackBar1.Value;
            Camera1.Set_ExposureTime(Cam1_ExpTime);
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            Cam2_ExpTime = trackBar2.Value;
            Camera2.Set_ExposureTime(Cam2_ExpTime);
        }

        private void rBt_Freerun_CheckedChanged(object sender, EventArgs e)
        {
            //set Freerun
            if (rBt_Freerun.Checked)
                Camera1.Set_TriggerSource(1);//Freerun
        }
        private void rBt_Freerun2_CheckedChanged(object sender, EventArgs e)
        {
            if (rBt_Freerun2.Checked)
                Camera2.Set_TriggerSource(1);//Freerun
        }
        private void rBt_HardTri_CheckedChanged(object sender, EventArgs e)
        {
            //set Line1
            if (rBt_HardTri.Checked )
                Camera1.Set_TriggerSource(2);//Line1
        }
        
        private void rBt_HardTri2_CheckedChanged(object sender, EventArgs e)
        {
            if (rBt_HardTri2.Checked)
                Camera2.Set_TriggerSource(2);//Line1
        }

       

        private void rBt_SoftTri_CheckedChanged(object sender, EventArgs e)
        {
            //set Software
            if (rBt_SoftTri.Checked)
            {
                Camera1.Set_TriggerSource(3);
                if (Camera1.IsAcquring)
                {
                    bT_SendSoftTri.Enabled = true;//相机必须要在采集状态才能接收到软/硬件触发信号
                }
                else
                {
                    bT_SendSoftTri.Enabled = false;//
                }
            }
            else
            {
                bT_SendSoftTri.Enabled = false;
            }

        }
        private void rBt_SoftTri2_CheckedChanged(object sender, EventArgs e)
        {
            if (rBt_SoftTri2.Checked)
            {
                Camera2.Set_TriggerSource(3);//Software
                if (Camera2.IsAcquring)
                {
                    bT_SendSoftTri2.Enabled = true;//相机必须要在采集状态才能接收到软/硬件触发信号
                }
                else
                {
                    bT_SendSoftTri2.Enabled = false;//
                }
            }
            else
            {
                bT_SendSoftTri2.Enabled = false;
            }

        }

        private void bT_SendSoftTri_Click(object sender, EventArgs e)
        {
            //LogMessage("start");
            Camera1.SendSoftwareTrigger();
        }
        private void bT_SendSoftTri2_Click(object sender, EventArgs e)
        {
            Camera2.SendSoftwareTrigger();
        }

        private void panel_Left_Resize(object sender, EventArgs e)//窗口调整
        {
            int pW = panel_Left.Width;
            int pH = panel_Left.Height;
            int pX=panel_Left.Location.X;
            int pY=panel_Left.Location.Y;

            panel1.SetBounds(pX +1,pY +1,(int)( pW*0.49),(int)(pH*0.49));
            panel2.SetBounds(pX + 1+(int)(pW * 0.49), pY + 1, (int)(pW * 0.49), (int)(pH * 0.49));
            panel3.SetBounds(pX + 1, pY + 1 + (int)(pH * 0.49), (int)(pW * 0.49), (int)(pH * 0.49));
            panel4.SetBounds(pX + 1 + (int)(pW * 0.49), pY + 1 + (int)(pH * 0.49), (int)(pW * 0.49), (int)(pH * 0.49));
        }

        private void bT_Acqsingle_Click(object sender, EventArgs e)
        {
            try
            {
                //单张取图方法要在非采集的状态下、并且触发模式为Freerun
                if (!rBt_Freerun.Checked)
                {
                    rBt_Freerun.Checked = true;
                }

                m_PictureBox.Image = Camera1.AcquireSingleImage();
                
            }
            catch { }
        }

        private void m_PictureBox_Paint(object sender, PaintEventArgs e)
        {
            Camera1.ImageInUse = true;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Camera2.ImageInUse = true;
        }
             
    }
}
