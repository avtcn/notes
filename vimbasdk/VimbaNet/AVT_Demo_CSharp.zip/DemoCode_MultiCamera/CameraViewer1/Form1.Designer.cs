﻿namespace CameraViewer1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.m_PictureBox = new System.Windows.Forms.PictureBox();
            this.tB_Log = new System.Windows.Forms.TextBox();
            this.panel_Left = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.p_SetCam1 = new System.Windows.Forms.Panel();
            this.bT_Acqsingle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.bT_Acqure = new System.Windows.Forms.Button();
            this.gBx_Cam1Tri = new System.Windows.Forms.GroupBox();
            this.bT_SendSoftTri = new System.Windows.Forms.Button();
            this.rBt_SoftTri = new System.Windows.Forms.RadioButton();
            this.rBt_HardTri = new System.Windows.Forms.RadioButton();
            this.rBt_Freerun = new System.Windows.Forms.RadioButton();
            this.bT_OpenCamera = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.p_SetCam2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.bT_Acqure2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bT_SendSoftTri2 = new System.Windows.Forms.Button();
            this.rBt_SoftTri2 = new System.Windows.Forms.RadioButton();
            this.rBt_HardTri2 = new System.Windows.Forms.RadioButton();
            this.rBt_Freerun2 = new System.Windows.Forms.RadioButton();
            this.bT_OpenCamera2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Log = new System.Windows.Forms.GroupBox();
            this.panel_Right = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.m_PictureBox)).BeginInit();
            this.panel_Left.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.p_SetCam1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.gBx_Cam1Tri.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.p_SetCam2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.Log.SuspendLayout();
            this.panel_Right.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_PictureBox
            // 
            this.m_PictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.m_PictureBox.BackColor = System.Drawing.Color.Navy;
            this.m_PictureBox.Location = new System.Drawing.Point(7, 4);
            this.m_PictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.m_PictureBox.Name = "m_PictureBox";
            this.m_PictureBox.Size = new System.Drawing.Size(344, 275);
            this.m_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.m_PictureBox.TabIndex = 3;
            this.m_PictureBox.TabStop = false;
            this.m_PictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.m_PictureBox_Paint);
            // 
            // tB_Log
            // 
            this.tB_Log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tB_Log.Location = new System.Drawing.Point(5, 18);
            this.tB_Log.Margin = new System.Windows.Forms.Padding(2);
            this.tB_Log.Multiline = true;
            this.tB_Log.Name = "tB_Log";
            this.tB_Log.Size = new System.Drawing.Size(190, 576);
            this.tB_Log.TabIndex = 6;
            // 
            // panel_Left
            // 
            this.panel_Left.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Left.Controls.Add(this.panel3);
            this.panel_Left.Controls.Add(this.panel4);
            this.panel_Left.Controls.Add(this.panel2);
            this.panel_Left.Controls.Add(this.panel1);
            this.panel_Left.Location = new System.Drawing.Point(-1, 0);
            this.panel_Left.Margin = new System.Windows.Forms.Padding(2);
            this.panel_Left.Name = "panel_Left";
            this.panel_Left.Size = new System.Drawing.Size(742, 610);
            this.panel_Left.TabIndex = 9;
            this.panel_Left.Resize += new System.EventHandler(this.panel_Left_Resize);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Location = new System.Drawing.Point(3, 302);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(357, 305);
            this.panel3.TabIndex = 30;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.p_SetCam1);
            this.groupBox1.Controls.Add(this.bT_OpenCamera);
            this.groupBox1.Location = new System.Drawing.Point(3, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(351, 290);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "相机1";
            // 
            // p_SetCam1
            // 
            this.p_SetCam1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.p_SetCam1.Controls.Add(this.bT_Acqsingle);
            this.p_SetCam1.Controls.Add(this.label1);
            this.p_SetCam1.Controls.Add(this.trackBar1);
            this.p_SetCam1.Controls.Add(this.bT_Acqure);
            this.p_SetCam1.Controls.Add(this.gBx_Cam1Tri);
            this.p_SetCam1.Location = new System.Drawing.Point(4, 58);
            this.p_SetCam1.Name = "p_SetCam1";
            this.p_SetCam1.Size = new System.Drawing.Size(341, 226);
            this.p_SetCam1.TabIndex = 24;
            // 
            // bT_Acqsingle
            // 
            this.bT_Acqsingle.Location = new System.Drawing.Point(191, 5);
            this.bT_Acqsingle.Name = "bT_Acqsingle";
            this.bT_Acqsingle.Size = new System.Drawing.Size(100, 23);
            this.bT_Acqsingle.TabIndex = 26;
            this.bT_Acqsingle.Text = "单张采图/拍照";
            this.bT_Acqsingle.UseVisualStyleBackColor = true;
            this.bT_Acqsingle.Click += new System.EventHandler(this.bT_Acqsingle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "曝光时间";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(67, 48);
            this.trackBar1.Maximum = 800000;
            this.trackBar1.Minimum = 71;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(261, 45);
            this.trackBar1.TabIndex = 25;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Value = 100;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // bT_Acqure
            // 
            this.bT_Acqure.Location = new System.Drawing.Point(3, 5);
            this.bT_Acqure.Name = "bT_Acqure";
            this.bT_Acqure.Size = new System.Drawing.Size(119, 23);
            this.bT_Acqure.TabIndex = 22;
            this.bT_Acqure.Text = "开始采集/OnLine";
            this.bT_Acqure.UseVisualStyleBackColor = true;
            this.bT_Acqure.Click += new System.EventHandler(this.bT_Acqure_Click);
            // 
            // gBx_Cam1Tri
            // 
            this.gBx_Cam1Tri.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gBx_Cam1Tri.Controls.Add(this.bT_SendSoftTri);
            this.gBx_Cam1Tri.Controls.Add(this.rBt_SoftTri);
            this.gBx_Cam1Tri.Controls.Add(this.rBt_HardTri);
            this.gBx_Cam1Tri.Controls.Add(this.rBt_Freerun);
            this.gBx_Cam1Tri.Location = new System.Drawing.Point(3, 95);
            this.gBx_Cam1Tri.Name = "gBx_Cam1Tri";
            this.gBx_Cam1Tri.Size = new System.Drawing.Size(335, 128);
            this.gBx_Cam1Tri.TabIndex = 23;
            this.gBx_Cam1Tri.TabStop = false;
            this.gBx_Cam1Tri.Text = "触发设置";
            // 
            // bT_SendSoftTri
            // 
            this.bT_SendSoftTri.Enabled = false;
            this.bT_SendSoftTri.Location = new System.Drawing.Point(188, 100);
            this.bT_SendSoftTri.Name = "bT_SendSoftTri";
            this.bT_SendSoftTri.Size = new System.Drawing.Size(75, 24);
            this.bT_SendSoftTri.TabIndex = 24;
            this.bT_SendSoftTri.Text = "发送软指令";
            this.bT_SendSoftTri.UseVisualStyleBackColor = true;
            this.bT_SendSoftTri.Click += new System.EventHandler(this.bT_SendSoftTri_Click);
            // 
            // rBt_SoftTri
            // 
            this.rBt_SoftTri.AutoSize = true;
            this.rBt_SoftTri.Location = new System.Drawing.Point(62, 104);
            this.rBt_SoftTri.Name = "rBt_SoftTri";
            this.rBt_SoftTri.Size = new System.Drawing.Size(61, 17);
            this.rBt_SoftTri.TabIndex = 25;
            this.rBt_SoftTri.TabStop = true;
            this.rBt_SoftTri.Text = "软触发";
            this.rBt_SoftTri.UseVisualStyleBackColor = true;
            this.rBt_SoftTri.CheckedChanged += new System.EventHandler(this.rBt_SoftTri_CheckedChanged);
            // 
            // rBt_HardTri
            // 
            this.rBt_HardTri.AutoSize = true;
            this.rBt_HardTri.Location = new System.Drawing.Point(62, 72);
            this.rBt_HardTri.Name = "rBt_HardTri";
            this.rBt_HardTri.Size = new System.Drawing.Size(73, 17);
            this.rBt_HardTri.TabIndex = 24;
            this.rBt_HardTri.Text = "硬件触发";
            this.rBt_HardTri.UseVisualStyleBackColor = true;
            this.rBt_HardTri.CheckedChanged += new System.EventHandler(this.rBt_HardTri_CheckedChanged);
            // 
            // rBt_Freerun
            // 
            this.rBt_Freerun.AutoSize = true;
            this.rBt_Freerun.Checked = true;
            this.rBt_Freerun.Location = new System.Drawing.Point(62, 40);
            this.rBt_Freerun.Name = "rBt_Freerun";
            this.rBt_Freerun.Size = new System.Drawing.Size(73, 17);
            this.rBt_Freerun.TabIndex = 23;
            this.rBt_Freerun.TabStop = true;
            this.rBt_Freerun.Text = "自由运行";
            this.rBt_Freerun.UseVisualStyleBackColor = true;
            this.rBt_Freerun.CheckedChanged += new System.EventHandler(this.rBt_Freerun_CheckedChanged);
            // 
            // bT_OpenCamera
            // 
            this.bT_OpenCamera.Location = new System.Drawing.Point(6, 29);
            this.bT_OpenCamera.Name = "bT_OpenCamera";
            this.bT_OpenCamera.Size = new System.Drawing.Size(75, 23);
            this.bT_OpenCamera.TabIndex = 20;
            this.bT_OpenCamera.Text = "打开相机";
            this.bT_OpenCamera.UseVisualStyleBackColor = true;
            this.bT_OpenCamera.Click += new System.EventHandler(this.bT_OpenCamera_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox2);
            this.panel4.Location = new System.Drawing.Point(366, 301);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(370, 306);
            this.panel4.TabIndex = 29;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.p_SetCam2);
            this.groupBox2.Controls.Add(this.bT_OpenCamera2);
            this.groupBox2.Location = new System.Drawing.Point(6, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 290);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "相机2";
            // 
            // p_SetCam2
            // 
            this.p_SetCam2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.p_SetCam2.Controls.Add(this.label2);
            this.p_SetCam2.Controls.Add(this.trackBar2);
            this.p_SetCam2.Controls.Add(this.bT_Acqure2);
            this.p_SetCam2.Controls.Add(this.groupBox3);
            this.p_SetCam2.Location = new System.Drawing.Point(4, 58);
            this.p_SetCam2.Name = "p_SetCam2";
            this.p_SetCam2.Size = new System.Drawing.Size(350, 226);
            this.p_SetCam2.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "曝光时间";
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(67, 48);
            this.trackBar2.Maximum = 800000;
            this.trackBar2.Minimum = 71;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(261, 45);
            this.trackBar2.TabIndex = 25;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar2.Value = 100;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // bT_Acqure2
            // 
            this.bT_Acqure2.Location = new System.Drawing.Point(3, 5);
            this.bT_Acqure2.Name = "bT_Acqure2";
            this.bT_Acqure2.Size = new System.Drawing.Size(119, 23);
            this.bT_Acqure2.TabIndex = 22;
            this.bT_Acqure2.Text = "开始采集/OnLine";
            this.bT_Acqure2.UseVisualStyleBackColor = true;
            this.bT_Acqure2.Click += new System.EventHandler(this.bT_Acqure2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.bT_SendSoftTri2);
            this.groupBox3.Controls.Add(this.rBt_SoftTri2);
            this.groupBox3.Controls.Add(this.rBt_HardTri2);
            this.groupBox3.Controls.Add(this.rBt_Freerun2);
            this.groupBox3.Location = new System.Drawing.Point(3, 95);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(344, 128);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "触发设置";
            // 
            // bT_SendSoftTri2
            // 
            this.bT_SendSoftTri2.Enabled = false;
            this.bT_SendSoftTri2.Location = new System.Drawing.Point(188, 100);
            this.bT_SendSoftTri2.Name = "bT_SendSoftTri2";
            this.bT_SendSoftTri2.Size = new System.Drawing.Size(75, 24);
            this.bT_SendSoftTri2.TabIndex = 24;
            this.bT_SendSoftTri2.Text = "发送软指令";
            this.bT_SendSoftTri2.UseVisualStyleBackColor = true;
            this.bT_SendSoftTri2.Click += new System.EventHandler(this.bT_SendSoftTri2_Click);
            // 
            // rBt_SoftTri2
            // 
            this.rBt_SoftTri2.AutoSize = true;
            this.rBt_SoftTri2.Location = new System.Drawing.Point(62, 104);
            this.rBt_SoftTri2.Name = "rBt_SoftTri2";
            this.rBt_SoftTri2.Size = new System.Drawing.Size(61, 17);
            this.rBt_SoftTri2.TabIndex = 25;
            this.rBt_SoftTri2.TabStop = true;
            this.rBt_SoftTri2.Text = "软触发";
            this.rBt_SoftTri2.UseVisualStyleBackColor = true;
            this.rBt_SoftTri2.CheckedChanged += new System.EventHandler(this.rBt_SoftTri2_CheckedChanged);
            // 
            // rBt_HardTri2
            // 
            this.rBt_HardTri2.AutoSize = true;
            this.rBt_HardTri2.Location = new System.Drawing.Point(62, 72);
            this.rBt_HardTri2.Name = "rBt_HardTri2";
            this.rBt_HardTri2.Size = new System.Drawing.Size(73, 17);
            this.rBt_HardTri2.TabIndex = 24;
            this.rBt_HardTri2.Text = "硬件触发";
            this.rBt_HardTri2.UseVisualStyleBackColor = true;
            this.rBt_HardTri2.CheckedChanged += new System.EventHandler(this.rBt_HardTri2_CheckedChanged);
            // 
            // rBt_Freerun2
            // 
            this.rBt_Freerun2.AutoSize = true;
            this.rBt_Freerun2.Checked = true;
            this.rBt_Freerun2.Location = new System.Drawing.Point(62, 40);
            this.rBt_Freerun2.Name = "rBt_Freerun2";
            this.rBt_Freerun2.Size = new System.Drawing.Size(73, 17);
            this.rBt_Freerun2.TabIndex = 23;
            this.rBt_Freerun2.TabStop = true;
            this.rBt_Freerun2.Text = "自由运行";
            this.rBt_Freerun2.UseVisualStyleBackColor = true;
            this.rBt_Freerun2.CheckedChanged += new System.EventHandler(this.rBt_Freerun2_CheckedChanged);
            // 
            // bT_OpenCamera2
            // 
            this.bT_OpenCamera2.Location = new System.Drawing.Point(6, 29);
            this.bT_OpenCamera2.Name = "bT_OpenCamera2";
            this.bT_OpenCamera2.Size = new System.Drawing.Size(75, 23);
            this.bT_OpenCamera2.TabIndex = 20;
            this.bT_OpenCamera2.Text = "打开相机";
            this.bT_OpenCamera2.UseVisualStyleBackColor = true;
            this.bT_OpenCamera2.Click += new System.EventHandler(this.bT_OpenCamera2_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(366, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(370, 286);
            this.panel2.TabIndex = 28;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Navy;
            this.pictureBox1.Location = new System.Drawing.Point(6, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(360, 275);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.m_PictureBox);
            this.panel1.Location = new System.Drawing.Point(3, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(357, 286);
            this.panel1.TabIndex = 27;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            // 
            // Log
            // 
            this.Log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Log.Controls.Add(this.tB_Log);
            this.Log.Location = new System.Drawing.Point(3, 8);
            this.Log.Name = "Log";
            this.Log.Size = new System.Drawing.Size(200, 599);
            this.Log.TabIndex = 25;
            this.Log.TabStop = false;
            this.Log.Text = "Log";
            // 
            // panel_Right
            // 
            this.panel_Right.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Right.Controls.Add(this.Log);
            this.panel_Right.Location = new System.Drawing.Point(743, 0);
            this.panel_Right.Name = "panel_Right";
            this.panel_Right.Size = new System.Drawing.Size(206, 610);
            this.panel_Right.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 613);
            this.Controls.Add(this.panel_Right);
            this.Controls.Add(this.panel_Left);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "AVTCamera_Viewer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.m_PictureBox)).EndInit();
            this.panel_Left.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.p_SetCam1.ResumeLayout(false);
            this.p_SetCam1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.gBx_Cam1Tri.ResumeLayout(false);
            this.gBx_Cam1Tri.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.p_SetCam2.ResumeLayout(false);
            this.p_SetCam2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.Log.ResumeLayout(false);
            this.Log.PerformLayout();
            this.panel_Right.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox m_PictureBox;
        private System.Windows.Forms.TextBox tB_Log;
        private System.Windows.Forms.Panel panel_Left;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button bT_OpenCamera;
        private System.Windows.Forms.Button bT_Acqure;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox Log;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_Right;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox gBx_Cam1Tri;
        private System.Windows.Forms.RadioButton rBt_SoftTri;
        private System.Windows.Forms.RadioButton rBt_HardTri;
        private System.Windows.Forms.RadioButton rBt_Freerun;
        private System.Windows.Forms.Button bT_SendSoftTri;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel p_SetCam1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel p_SetCam2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Button bT_Acqure2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button bT_SendSoftTri2;
        private System.Windows.Forms.RadioButton rBt_SoftTri2;
        private System.Windows.Forms.RadioButton rBt_HardTri2;
        private System.Windows.Forms.RadioButton rBt_Freerun2;
        private System.Windows.Forms.Button bT_OpenCamera2;
        private System.Windows.Forms.Button bT_Acqsingle;
    }
}

