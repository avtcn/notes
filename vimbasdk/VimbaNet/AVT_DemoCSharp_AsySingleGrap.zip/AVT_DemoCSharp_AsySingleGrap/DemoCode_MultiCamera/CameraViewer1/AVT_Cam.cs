﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using AVT.VmbAPINET;
namespace CameraViewer1
{
   

   public class AVT_Cam
    {
        private Semaphore sem = new Semaphore(0, 1);
        private Frame m_frame = null;
      
        public bool IsOpen {get;set;}
        public bool IsAcquring { get; set; }
        public Camera m_Cam {get; set;}

        public AVT_Cam() 
        {
            IsOpen = false;
            IsAcquring = false;
            m_Cam = null;
            
        }
       
        public bool OpenCamera()
        {
            try
            {
                this.m_Cam.Open(VmbAccessModeType.VmbAccessModeFull);
                if (m_Cam.InterfaceType == VmbInterfaceType.VmbInterfaceEthernet)
                {
                    m_Cam.Features["GVSPAdjustPacketSize"].RunCommand();//自动调整数据包大小
                    while (false == m_Cam.Features["GVSPAdjustPacketSize"].IsCommandDone())
                    {
                        // Do Nothing
                    }
                }
               // AdjustPixelFormat(m_Cam);//可用可不用
                 Set_TriggerSource(3);// 设置为软触发
                 StartAcquisition();// 开始采集

                IsOpen = true;               
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void CloseCamera()
        {
            try
            {
                if (IsAcquring)//实际上直接关闭相机也可以
                {
                    StopAcquisition();
                }
                m_Cam.Close();
                IsOpen = false;                
            }
            catch
            {
            }
        }

        public void SendSoftwareTrigger()
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }
            this.m_Cam.Features["TriggerSoftware"].RunCommand();
            while (false == m_Cam.Features["TriggerSoftware"].IsCommandDone())
            {
                // Do nothing
            }              
           
        }
             
        public void Set_TriggerSource(int Tri_index)
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }
            switch (Tri_index)
            {
                case 1:
                    this.m_Cam.Features["TriggerSource"].EnumValue = "Freerun";
                    break;
                case 2:
                    this.m_Cam.Features["TriggerSource"].EnumValue = "Line1";
                    break;
                case 3:
                    this.m_Cam.Features["TriggerSource"].EnumValue = "Software";
                    break;
            }
            // And switch it on or off
            this.m_Cam.Features["TriggerMode"].EnumValue = "On";
            this.m_Cam.Features["AcquisitionMode"].EnumValue = "Continuous";
        }             
       
        public double ReadExposureTime()
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }  
            if (m_Cam.Features.ContainsName("ExposureTime"))//目前千兆网相机中Goldeye的属性名称略有不同
            {
                return m_Cam.Features["ExposureTime"].FloatValue;
            }
            else
            {
                return m_Cam.Features["ExposureTimeAbs"].FloatValue;
            }
          
        }
       
        public void Set_ExposureTime(double time)
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }  
            if (m_Cam.Features.ContainsName("ExposureTime"))//目前千兆网相机中Goldeye的属性名称略有不同
            {
                m_Cam.Features["ExposureTime"].FloatValue = time;
            }
            else
            {
                m_Cam.Features["ExposureTimeAbs"].FloatValue = time;
            }
           
        }
       
        private void m_CamOnFrameReceived(Frame frame)
        {          
            if (VmbFrameStatusType.VmbFrameStatusComplete == frame.ReceiveStatus)
            {
                m_frame = frame;
                sem.Release();
            }
            try
            {
                m_Cam.QueueFrame(frame);
            }
            catch
            {
                // Do nothing
                //System.Diagnostics.Debug.WriteLine("camera " + index + ":  name is " + m_Camera.Name + ", model is " + m_Camera.Model);
            }
        }

        public void StartAcquisition()
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }
                             
            try
            {
                m_Cam.OnFrameReceived += new Camera.OnFrameReceivedHandler(m_CamOnFrameReceived);//注册图像接收事件
                m_Cam.StartContinuousImageAcquisition(3);
                //m_Cam.Features["AcquisitionStart"].RunCommand();//作用和上一句相同，但是标准写法是这一句
                IsAcquring = true;
            }
            catch { }  
        }

        public void StopAcquisition()
        {
            if (null == this.m_Cam)
            {
                throw new NullReferenceException("No camera retrieved.");
            }
            try
            {                
                m_Cam.OnFrameReceived -= m_CamOnFrameReceived;
                m_Cam.StopContinuousImageAcquisition();
                IsAcquring = false;
                //m_Cam.Features["AcquisitionStop"].RunCommand();//作用和上一句相同，但是标准写法是这一句
            }
            catch { }        
        }
      
        public Bitmap AcquireSingleImage(int timeout)
        {
            try
            {
                Bitmap btmap = null;

                SendSoftwareTrigger();

                if (sem.WaitOne(timeout))
                {
                    btmap = ConvertFrame(m_frame);
                    return btmap;
                }
                else
                {
                    return null;
                }

            }
            catch
            {
                return null;
            }      
        }
        private Bitmap ConvertFrame(Frame frame)
        {
            if (null == frame)
            {
                throw new ArgumentNullException("frame");
            }

            // Check if the image is valid
            if (VmbFrameStatusType.VmbFrameStatusComplete != frame.ReceiveStatus)
            {
                throw new Exception("Invalid frame received. Reason: " + frame.ReceiveStatus.ToString());
            }

            // define return variable
            Bitmap tempbmp = null;
            frame.Fill(ref tempbmp);
            return tempbmp;
        }
        
        private void AdjustPixelFormat(Camera camera)
        {
            if (null == camera)
            {
                throw new ArgumentNullException("camera");
            }

            string[] supportedPixelFormats = new string[] { "BGR8Packed", "Mono8" };
            //Check for compatible pixel format
            Feature pixelFormatFeature = camera.Features["PixelFormat"];

            //Determine current pixel format
            string currentPixelFormat = pixelFormatFeature.EnumValue;

            //Check if current pixel format is supported
            bool currentPixelFormatSupported = false;
            foreach (string supportedPixelFormat in supportedPixelFormats)
            {
                if (string.Compare(currentPixelFormat, supportedPixelFormat, StringComparison.Ordinal) == 0)
                {
                    currentPixelFormatSupported = true;
                    break;
                }
            }

            //Only adjust pixel format if we not already have a compatible one.
            if (false == currentPixelFormatSupported)
            {
                //Determine available pixel formats
                string[] availablePixelFormats = pixelFormatFeature.EnumValues;

                //Check if there is a supported pixel format
                bool pixelFormatSet = false;
                foreach (string supportedPixelFormat in supportedPixelFormats)
                {
                    foreach (string availablePixelFormat in availablePixelFormats)
                    {
                        if ((string.Compare(supportedPixelFormat, availablePixelFormat, StringComparison.Ordinal) == 0)
                            && (pixelFormatFeature.IsEnumValueAvailable(supportedPixelFormat) == true))
                        {
                            //Set the found pixel format
                            pixelFormatFeature.EnumValue = supportedPixelFormat;
                            pixelFormatSet = true;
                            break;
                        }
                    }

                    if (true == pixelFormatSet)
                    {
                        break;
                    }
                }

                if (false == pixelFormatSet)
                {
                    throw new Exception("None of the pixel formats that are supported by this example (Mono8 and BRG8Packed) can be set in the camera.");
                }
            }
        }
    }
}
