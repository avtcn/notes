﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using AVT.VmbAPINET;
//Demo说明

//用异步软触发的方式代替同步采集
//支持两个相机（可扩展至多相机）

//为了便于理解，简化了官方例程的一些函数
//如果需要获取动态的相机列表，可以参考官方自带的AsynchronousGrab例程

namespace CameraViewer1
{
   
    public partial class Form1 : Form
    {
       

        private Vimba m_Vimba = null;
        private AVT_Cam Camera1, Camera2;

        double Cam1_ExpTime = 1500;
       
        double Cam2_ExpTime = 1500;
        
        public Form1()
        {
            InitializeComponent();
        }
        private void LogMessage(string message)
        {
            if (null == message)
            {
                throw new ArgumentNullException("message");
            }
            tB_Log.AppendText(string.Format("{0:yyyy-MM-dd HH:mm:ss.fff}: {1}", DateTime.Now, message) + "\r\n");       
        }
      
        //Add an error log message and show an error message box
        private void LogError(string message)
        {
            LogMessage(message);

            MessageBox.Show(message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        private void Init_Camera()
        {
            
            try
            {
                Camera1 = new AVT_Cam();
                Camera1.m_Cam  = m_Vimba.GetCameraByID("192.168.20.12");//两种方式都可以打开，注意用IP打开智能打开设置了固定IP的相机
                //Camera1.m_Cam = m_Vimba.GetCameraByID("DEV_000F314D95AE") ;  //注意是DEV开头的        
                bT_OpenCamera.Enabled = true;
                LogMessage("相机1初始化成功");
               
            }
            catch
            {
                bT_OpenCamera.Enabled = false;
                LogMessage("相机1初始化失败");
            }
            try
            {
                Camera2 = new AVT_Cam();
                Camera2.m_Cam = m_Vimba.GetCameraByID("192.168.4.66");
                bT_OpenCamera2.Enabled = true;
                LogMessage("相机2初始化成功");                
            }
            catch
            {
                bT_OpenCamera2.Enabled = false;
                LogMessage("相机2初始化失败"); 
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            try 
            {
                Vimba vimba = new Vimba();
                vimba.Startup();
                m_Vimba = vimba;
                Init_Camera();
                updateControls();
                updateControls2();
            }
            catch(Exception exception)
            {
                LogError("Could not startup Vimba API. Reason: " + exception.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (null == m_Vimba)
            {
                throw new Exception("Vimba has not been started.");
            }
            m_Vimba.Shutdown();
            m_Vimba = null;           
        }
            
        private void bT_OpenCamera_Click(object sender, EventArgs e)
        {
            if (!Camera1.IsOpen)
            {
                bool IsOpen= Camera1.OpenCamera();
                if (IsOpen)
               {
                   //-------读取相机参数到界面-----                               
                   Cam1_ExpTime = Camera1.ReadExposureTime();
                   trackBar1.Value = (int)Cam1_ExpTime;                 
                   LogMessage("相机1打开成功！");
               }
               else
               {
                   LogMessage("相机1打开失败，请检查IP配置");
               }
 
            }
            else
            {
                Camera1.CloseCamera();
            }

            updateControls();            
                
        }
        private void bT_OpenCamera2_Click(object sender, EventArgs e)
        {
            if (!Camera2.IsOpen)
            {
                Camera2.OpenCamera();               
                //-------读取相机参数到界面-----                               
                Cam2_ExpTime = Camera2.ReadExposureTime();
                trackBar2.Value = (int)Cam2_ExpTime;              
               
            }
            else
            {
                Camera2.CloseCamera();
            }

            updateControls2();  

        }           
       
        private void updateControls()
        {           
            if (Camera1.IsOpen)
            {
                bT_OpenCamera.Text = "关闭相机";
                p_SetCam1.Enabled = true;//任何关于相机的设置都要在相机打开的前提下，设置触发方式或者曝光时间则尽量要在相机停止采集的状态下
                               
            }
            else
            {             
                bT_OpenCamera.Text = "打开相机";
                p_SetCam1.Enabled = false;
            }
        }

        private void updateControls2()
        {
            if (Camera2.IsOpen)
            {
                bT_OpenCamera2.Text = "关闭相机";
                p_SetCam2.Enabled = true;//任何关于相机的设置都要在相机打开的前提下，设置触发方式或者曝光时间则尽量要在相机停止采集的状态下
               
            }
            else
            {
                bT_OpenCamera2.Text = "打开相机";
                p_SetCam2.Enabled = false;
            }
        }


        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Cam1_ExpTime = trackBar1.Value;
            Camera1.Set_ExposureTime(Cam1_ExpTime);
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            Cam2_ExpTime = trackBar2.Value;
            Camera2.Set_ExposureTime(Cam2_ExpTime);
        }
       
        private void panel_Left_Resize(object sender, EventArgs e)//窗口调整
        {
            int pW = panel_Left.Width;
            int pH = panel_Left.Height;
            int pX=panel_Left.Location.X;
            int pY=panel_Left.Location.Y;

            panel1.SetBounds(pX +1,pY +1,(int)( pW*0.49),(int)(pH*0.49));
            panel2.SetBounds(pX + 1+(int)(pW * 0.49), pY + 1, (int)(pW * 0.49), (int)(pH * 0.49));
            panel3.SetBounds(pX + 1, pY + 1 + (int)(pH * 0.49), (int)(pW * 0.49), (int)(pH * 0.49));
            panel4.SetBounds(pX + 1 + (int)(pW * 0.49), pY + 1 + (int)(pH * 0.49), (int)(pW * 0.49), (int)(pH * 0.49));
        }

        private void bT_Acqsingle_Click(object sender, EventArgs e)
        {            
                         
            m_PictureBox.Image = Camera1.AcquireSingleImage(1000); 
            //Thread s1 = new Thread(acqtest);
            //s1.Start();                                         
        }
        private void bT_Acqsingle2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Camera2.AcquireSingleImage(1000);
            //Thread sI = new Thread(acqtest2);
            //sI.Start();

        }
        private void acqtest()
        {          
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);
                m_PictureBox.Image = Camera1.AcquireSingleImage(1000);               
            }
        }
        private void acqtest2()
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);                
                pictureBox1.Image = Camera2.AcquireSingleImage(1000);
            }

        }
       
             
    }
}
