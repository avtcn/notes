﻿Imports avt.VmbAPINET
Imports System.Drawing
Imports System.Drawing.Imaging

Public Class RingBitmap
     
    Private m_Size As Integer = 0

    Private m_Bitmaps() As Bitmap = Nothing

    Private m_BitmapSelector As Integer = 0


    Sub New(ByVal Size As Integer)

        m_Size = Size
        m_Bitmaps = New Bitmap(m_Size) {}

    End Sub

    Public ReadOnly Property m_Image() As Bitmap
        Get
            m_Image = m_Bitmaps(m_BitmapSelector)
        End Get
    End Property
       
    Public Sub FillNextBitmap(ByVal mframe As Frame)
        ' switch to Bitmap object which is currently not in use by GUI
        SwitchBitmap()
        mframe.Fill(m_Bitmaps(m_BitmapSelector))
    End Sub

    Private Sub SwitchBitmap()
        m_BitmapSelector += 1
        If (m_Size = m_BitmapSelector) Then
            m_BitmapSelector = 0
        End If
    End Sub

End Class
