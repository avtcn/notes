﻿
Imports avt.VmbAPINET
Imports System.Drawing
Imports System.Drawing.Imaging
'Demo说明

'支持同步采集、异步采集两种模式
'支持1个相机（可扩展至多相机）

'为了便于理解，简化了官方例程的一些函数
'使用异步的方式连续采集时，可能会出现图片显示闪屏的BUG，如果有建议参考官方自带的AsynchronousGrab例程
Public Class Form1
    Dim myVimba As New Vimba
    Dim camera1, camera2 As New AVTcamera

    Private Sub LogMessage(ByVal message As String)        
        tB_Log.AppendText(String.Format("{0:yyyy-MM-dd HH:mm:ss.fff}: {1}", DateTime.Now, message) + vbCrLf)
    End Sub

    Private Sub InitCameras()

        Try           
            camera1.m_Cam = myVimba.GetCameraByID("192.168.0.12") '两种方式都可以
            'Camera1.m_Cam = m_Vimba.GetCameraByID("DEV_000F314D95AE")           
            Bt_Open.Enabled = True
            LogMessage("相机1初始化成功")
        Catch

            Bt_Open.Enabled = False
            LogMessage("相机1初始化失败")

        End Try
        

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        myVimba.Startup()
        'Dim cameras As CameraCollection = myVimba.Cameras 'vimba对象启动后会有相应的相机列表
        InitCameras()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        myVimba.Shutdown()
        myVimba = Nothing

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_Open.Click
        If camera1.IsOpen Then
            Try
                camera1.CloseCamera()
                Bt_Open.Text = "打开相机"
                Panel1.Enabled = False
                'LogMessage("相机1已关闭")
            Catch
                'LogMessage("相机1关闭失败")
            End Try

        Else
            Try
                camera1.OpenCamera()
                Bt_Open.Text = "关闭相机"
                Panel1.Enabled = True
                'LogMessage("相机1打开成功")
            Catch
                'LogMessage("相机1打开失败")
            End Try
        End If

    End Sub

    Private Sub Bt_AquireSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_AquireSingle.Click       

        LogMessage(String.Format("{0:mm:ss.ffff}->SingleCaptureStart", DateTime.Now))
        PictureBox1.Image = camera1.AcquireSingleImage()
        LogMessage(String.Format("{0:mm:ss.ffff}->SingleCaptureEnd", DateTime.Now))
    End Sub


    Private Sub Bt_AcquireContinous_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bt_AcquireContinous.Click

        If camera1.IsAcquring Then
            camera1.StopContinousAcquisition()
            Bt_AcquireContinous.Text = "开始采集"

        Else
            camera1.StartContinousAcquisition(New ImageReceivedHandler(AddressOf mCam1_OnFrameReceived))
            Bt_AcquireContinous.Text = "停止采集"
        End If

    End Sub

    Public Sub mCam1_OnFrameReceived(ByVal bmp As Bitmap)

        'If InvokeRequired = True Then'
        '    BeginInvoke(New ImageReceivedHandler(AddressOf mCam1_OnFrameReceived))
        '    Return
        'End If

        PictureBox1.Image = bmp

    End Sub

    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar1.Scroll
        Dim exposureTime As Double = TrackBar1.Value
        camera1.Set_ExposureTime(exposureTime)
    End Sub


    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked Then
            camera1.Set_TriggerSource(1)
            Bt_AquireSingle.Enabled = True '单张采图会有超时时间限制，使用其它触发方式比较难实现       
        End If

    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked Then
            camera1.Set_TriggerSource(2)
            Bt_AquireSingle.Enabled = False
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked Then
            camera1.Set_TriggerSource(3)
            Bt_AquireSingle.Enabled = False
        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        camera1.SendSoftwareTrigger()
    End Sub

    Private Sub PictureBox1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PictureBox1.Paint
        camera1.ImageInUse = True
    End Sub
End Class
