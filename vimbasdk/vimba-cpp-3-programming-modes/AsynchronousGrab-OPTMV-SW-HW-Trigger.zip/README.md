# Introduction 
Implement Free Run / Software Trigger / Hardware Trigger modes demonstration for OPTMV.
Show frame counts;
Show elapsed time since the acquisition starts;

# Features
Click to swith camera mode among Free Run / Software Trigger / Hardware Trigger;
Live view captured image from AVT camera;
Select one camera from cameras list before start;


# Getting Started
Based on Vimba C++ example: Vimba_2.1\VimbaCPP_Examples\AsynchronousGrab\MFC



# Build and Test 
Manta G125B passed @ 2018-08-22 18:15:33



# Contribute



# History
* Joe Ge - 2018-08-22 17:59:22 - Version 0.90
* Joe Ge - 2018-08-22 18:15:08 - Version 0.91
* Joe Ge - 2018-08-23 16:57:24 - Version 0.92
* Joe Ge - 2018-08-24 09:58:02 - Version 0.99




