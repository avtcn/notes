﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.IO;
using System.Collections.Generic;


namespace WindowsFormsApplication1
{
    public partial class DefectPoint : Form
    {
       // Triangle3DF 3df = new Triangle3DF(new PointF (1,2),new PointF (2,3),new PointF (0,4));
        int Grayth = 50;
        List<Point> DefectPointList = new List<Point>();
        Image<Gray, byte> CurImage = null;


        
        public DefectPoint()
        {
            
            InitializeComponent();
        }
       
        private void Bt_OpenImage_Click(object sender, EventArgs e)//打开一张图片读取坏点
        {
            //计算坏点过程禁止其他操作
            Bt_OpenImage.Enabled = false;
            Bt_SetGrayth.Enabled = false;          
            radioNormal.Enabled = false;
            radioCloumn.Enabled = false;
            radioArea.Enabled = false;

            textOutput.Text = "";
            textCount.Text = "0";

            OpenFileDialog op = new OpenFileDialog();
            if (op.ShowDialog() == DialogResult.OK)
            {
                
                Mat scr = new Mat(op.FileName, Emgu.CV.CvEnum.LoadImageType.AnyColor);
                Image<Gray, byte> image = scr.ToImage<Gray, byte>();               
                CurImage = image;
                imageBox1.Image = image;
               // Byte  n = image.Data[0,0,1];
                int count = 0;
                int Cur_i = 0;

                string Pre_Str = "";
                string Pre_Strh = "";
                string pre_text = "";//用于同列合并
                string Temp_Str = "";
                string str = "";

                StreamWriter sw = null;
                string filetxt = Application.StartupPath+ "\\"+string.Format("{0:MMddHHmmss}", DateTime.Now)+ "TestTxt.txt";

                if (!File.Exists(filetxt))
                {
                    FileStream fs1 = new FileStream(filetxt, FileMode.Create, FileAccess.Write);//创建写入文件
                    sw =new  StreamWriter(fs1);
                }
                else
                {
                    FileStream fs = new FileStream(filetxt, FileMode.Open, FileAccess.Write);
                    sw = new StreamWriter(fs);
                }

                for (int i=0;i<(image.Width - 1) ;i++)
                {
                    textCount.Text = count.ToString();//坏点计数
                    if (count > 500)
                    {
                        textOutput.AppendText("坏点计数超过500,查找已停止!请检查输入的图片或重新设定阈值");
                        break;
                    }

                    for (int j = 0; j <( image.Height - 1) ; j++)
                    {
                        Byte n = image.Data[j, i, 0];
                        
                        if ((n > Grayth && (!checkFinddark.Checked))||(n < Grayth && checkFinddark.Checked))//
                        {
                            sw.WriteLine(i + "," + j);//保存坏点到本地
                            DefectPointList.Add(new Point(i, j)); //保存坏点到DefectPointList(内存)
                                                                                  
                            if (radioNormal.Checked)//标准格式-->>显示灰度值
                            {
                                count += 1;
                                Pre_Strh = "(" + i + "," + j + ")";                             
                                Pre_Str = Pre_Strh + "<" + n + ">" + "\r\n";                                                             
                                textOutput.AppendText(Pre_Str);                                                             
                            }
                            else if(radioCloumn.Checked)//列格式-->>直接用于AVT自带的坏点矫正工具(列矫正）
                            {
                                if (checkMerge.Checked)//合并同属一列的坏点
                                { 
                                    if (i == Cur_i)
                                    {
                                        Temp_Str = Pre_Strh + j + "\r\n";                                   
                                        str = pre_text + Temp_Str;
                                        textOutput.Text = str;
                                        Pre_Str = Temp_Str;
                                    }
                                    else
                                    {
                                        count += 1;
                                        pre_text = textOutput.Text;                                  
                                        Pre_Strh = i + ":" + j + ",";
                                        Pre_Str = Pre_Strh + j + "\r\n";
                                        textOutput.AppendText(Pre_Str);                                          
                                        Cur_i = i;
                                    }
                                }
                                else
                                {
                                    count += 1;
                                    Pre_Strh = i + ":" + j + ",";
                                    Pre_Str = Pre_Strh + j + "\r\n";
                                    textOutput.AppendText(Pre_Str);
                                }
                            }
                            if (radioArea.Checked)//区域格式(块状区域暂时未实现合并)-->>直接用于AVT自带的点/块坏点矫正工具
                            {
                                count += 1;
                                Pre_Strh = i + "," + j + ",";                              
                                Pre_Str = Pre_Strh + 1 + "," + 1 + "\r\n";                                
                                textOutput.AppendText(Pre_Str);                               
                            }
                        }
                    }
                }                
                sw.Close();
            }

            Bt_OpenImage.Enabled = true;
            Bt_SetGrayth.Enabled = true;
            radioNormal.Enabled = true;
            radioCloumn.Enabled = true;
            radioArea.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textGreyth.Text = Grayth.ToString();
        }

        private void Bt_SetGrayth_Click(object sender, EventArgs e)//设置坏点阈值
        {
            if (textGreyth.Enabled)
            {
                try
                {
                    Grayth = Convert.ToInt32(textGreyth.Text);
                    Bt_SetGrayth.Text = "设置";
                    textGreyth.Enabled = false;
                    checkFinddark.Enabled = false;
                }
                catch
                {
                    Grayth = 50;
                }
            }
            else
            {
                Bt_SetGrayth.Text = "保存";
                textGreyth.Enabled = true;
                checkFinddark.Enabled = true;
            }

        }
      
        private void Bt_LoadPoints_Click(object sender, EventArgs e)//从txt中读取坏点,仅支持单点格式读取
        {
            OpenFileDialog op = new OpenFileDialog();
            if (op.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader sr = new StreamReader(op.FileName);

                    string line;
                    while (sr.Peek() > -1)
                    {
                        line = sr.ReadLine();
                        DefectPointList.Add(new Point(int.Parse(line.Split(',')[0]), int.Parse(line.Split(',')[1])));
                        line = "";

                    }
                    sr.Close();

                    for (int i = 0; i < DefectPointList.Count; i++)
                    {
                        textOutput.AppendText(DefectPointList[i].X + ":" + DefectPointList[i].Y + "\r\n");
                    }
                }
                catch { }

            }
        }



        private void Bt_Correction_Click(object sender, EventArgs e)//坏点矫正，仅支持单点矫正
        {

            if (!(CurImage == null))
            {
                Image<Gray, byte> image = CurImage;
                long start = DateTime.Now.Ticks;
                foreach (Point p in DefectPointList)
                {
                    if (p.Y == 0)
                    {
                        image.Data[p.Y, p.X, 0] = image.Data[p.Y, p.X + 1, 0];
                    }
                    else if (p.X == image.Size.Width - 1)
                    {
                        image.Data[p.Y, p.X, 0] = image.Data[p.Y, p.X - 1, 0];
                    }
                    else
                    {
                        int avg = (image.Data[p.Y, p.X + 1, 0] + image.Data[p.Y, p.X - 1, 0]) / 2;
                        Byte avgb = (Byte)avg;
                        image.Data[p.Y, p.X, 0] = (avgb);
                    }

                }
                long end = DateTime.Now.Ticks;
                double defectTime = (end - start) * 1.0 / TimeSpan.TicksPerSecond * 1000;
                image.Save(Application.StartupPath + "\\" + string.Format("{0:MMddHHmmss}", DateTime.Now) + "CorrectedImage.bmp");
            }
        }
        
        private void radioCloumn_CheckedChanged(object sender, EventArgs e)
        {
            if (radioCloumn.Checked)
            {
                checkMerge.Enabled = true;
            }
            else
            {
                checkMerge.Enabled = false;
               // checkMerge.Checked = false;
            }

        }
    }
}
