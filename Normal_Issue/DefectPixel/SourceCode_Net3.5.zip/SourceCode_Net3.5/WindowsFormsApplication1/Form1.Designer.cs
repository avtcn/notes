﻿namespace WindowsFormsApplication1
{
    partial class DefectPoint
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DefectPoint));
            this.imageBox1 = new Emgu.CV.UI.ImageBox();
            this.Bt_OpenImage = new System.Windows.Forms.Button();
            this.textOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textCount = new System.Windows.Forms.TextBox();
            this.textGreyth = new System.Windows.Forms.TextBox();
            this.Bt_SetGrayth = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkMerge = new System.Windows.Forms.CheckBox();
            this.radioArea = new System.Windows.Forms.RadioButton();
            this.radioCloumn = new System.Windows.Forms.RadioButton();
            this.radioNormal = new System.Windows.Forms.RadioButton();
            this.Bt_LoadPoints = new System.Windows.Forms.Button();
            this.Bt_Correction = new System.Windows.Forms.Button();
            this.checkFinddark = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageBox1
            // 
            this.imageBox1.BackColor = System.Drawing.SystemColors.Control;
            this.imageBox1.Location = new System.Drawing.Point(12, 2);
            this.imageBox1.Name = "imageBox1";
            this.imageBox1.Size = new System.Drawing.Size(561, 411);
            this.imageBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imageBox1.TabIndex = 2;
            this.imageBox1.TabStop = false;
            // 
            // Bt_OpenImage
            // 
            this.Bt_OpenImage.Location = new System.Drawing.Point(12, 419);
            this.Bt_OpenImage.Name = "Bt_OpenImage";
            this.Bt_OpenImage.Size = new System.Drawing.Size(171, 55);
            this.Bt_OpenImage.TabIndex = 4;
            this.Bt_OpenImage.Text = "打开图片";
            this.Bt_OpenImage.UseVisualStyleBackColor = true;
            this.Bt_OpenImage.Click += new System.EventHandler(this.Bt_OpenImage_Click);
            // 
            // textOutput
            // 
            this.textOutput.Location = new System.Drawing.Point(579, 54);
            this.textOutput.Multiline = true;
            this.textOutput.Name = "textOutput";
            this.textOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textOutput.Size = new System.Drawing.Size(225, 295);
            this.textOutput.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(576, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "坏点计数";
            // 
            // textCount
            // 
            this.textCount.Location = new System.Drawing.Point(640, 31);
            this.textCount.Name = "textCount";
            this.textCount.ReadOnly = true;
            this.textCount.Size = new System.Drawing.Size(59, 20);
            this.textCount.TabIndex = 7;
            this.textCount.Text = "0";
            // 
            // textGreyth
            // 
            this.textGreyth.Enabled = false;
            this.textGreyth.Location = new System.Drawing.Point(442, 436);
            this.textGreyth.Name = "textGreyth";
            this.textGreyth.Size = new System.Drawing.Size(36, 20);
            this.textGreyth.TabIndex = 8;
            // 
            // Bt_SetGrayth
            // 
            this.Bt_SetGrayth.Location = new System.Drawing.Point(489, 434);
            this.Bt_SetGrayth.Name = "Bt_SetGrayth";
            this.Bt_SetGrayth.Size = new System.Drawing.Size(44, 23);
            this.Bt_SetGrayth.TabIndex = 9;
            this.Bt_SetGrayth.Text = "设置";
            this.Bt_SetGrayth.UseVisualStyleBackColor = true;
            this.Bt_SetGrayth.Click += new System.EventHandler(this.Bt_SetGrayth_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 440);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "阈值";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkMerge);
            this.groupBox1.Controls.Add(this.radioArea);
            this.groupBox1.Controls.Add(this.radioCloumn);
            this.groupBox1.Controls.Add(this.radioNormal);
            this.groupBox1.Location = new System.Drawing.Point(579, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 119);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "输出选项";
            // 
            // checkMerge
            // 
            this.checkMerge.AutoSize = true;
            this.checkMerge.Enabled = false;
            this.checkMerge.Location = new System.Drawing.Point(106, 63);
            this.checkMerge.Name = "checkMerge";
            this.checkMerge.Size = new System.Drawing.Size(98, 17);
            this.checkMerge.TabIndex = 15;
            this.checkMerge.Text = "合并同列坏点";
            this.checkMerge.UseVisualStyleBackColor = true;
            // 
            // radioArea
            // 
            this.radioArea.AutoSize = true;
            this.radioArea.Location = new System.Drawing.Point(18, 92);
            this.radioArea.Name = "radioArea";
            this.radioArea.Size = new System.Drawing.Size(73, 17);
            this.radioArea.TabIndex = 14;
            this.radioArea.Text = "区域格式";
            this.radioArea.UseVisualStyleBackColor = true;
            // 
            // radioCloumn
            // 
            this.radioCloumn.AutoSize = true;
            this.radioCloumn.Location = new System.Drawing.Point(18, 62);
            this.radioCloumn.Name = "radioCloumn";
            this.radioCloumn.Size = new System.Drawing.Size(61, 17);
            this.radioCloumn.TabIndex = 13;
            this.radioCloumn.Text = "列格式";
            this.radioCloumn.UseVisualStyleBackColor = true;
            this.radioCloumn.CheckedChanged += new System.EventHandler(this.radioCloumn_CheckedChanged);
            // 
            // radioNormal
            // 
            this.radioNormal.AutoSize = true;
            this.radioNormal.Checked = true;
            this.radioNormal.Location = new System.Drawing.Point(18, 32);
            this.radioNormal.Name = "radioNormal";
            this.radioNormal.Size = new System.Drawing.Size(73, 17);
            this.radioNormal.TabIndex = 12;
            this.radioNormal.TabStop = true;
            this.radioNormal.Text = "标准格式";
            this.radioNormal.UseVisualStyleBackColor = true;
            // 
            // Bt_LoadPoints
            // 
            this.Bt_LoadPoints.Enabled = false;
            this.Bt_LoadPoints.Location = new System.Drawing.Point(203, 428);
            this.Bt_LoadPoints.Name = "Bt_LoadPoints";
            this.Bt_LoadPoints.Size = new System.Drawing.Size(70, 36);
            this.Bt_LoadPoints.TabIndex = 14;
            this.Bt_LoadPoints.Text = "从txt文件读取坏点";
            this.Bt_LoadPoints.UseVisualStyleBackColor = true;
            this.Bt_LoadPoints.Click += new System.EventHandler(this.Bt_LoadPoints_Click);
            // 
            // Bt_Correction
            // 
            this.Bt_Correction.Enabled = false;
            this.Bt_Correction.Location = new System.Drawing.Point(279, 428);
            this.Bt_Correction.Name = "Bt_Correction";
            this.Bt_Correction.Size = new System.Drawing.Size(75, 36);
            this.Bt_Correction.TabIndex = 15;
            this.Bt_Correction.Text = "坏点矫正";
            this.Bt_Correction.UseVisualStyleBackColor = true;
            this.Bt_Correction.Click += new System.EventHandler(this.Bt_Correction_Click);
            // 
            // checkFinddark
            // 
            this.checkFinddark.AutoSize = true;
            this.checkFinddark.Enabled = false;
            this.checkFinddark.Location = new System.Drawing.Point(442, 462);
            this.checkFinddark.Name = "checkFinddark";
            this.checkFinddark.Size = new System.Drawing.Size(74, 17);
            this.checkFinddark.TabIndex = 16;
            this.checkFinddark.Text = "查找暗点";
            this.checkFinddark.UseVisualStyleBackColor = true;
            // 
            // DefectPoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 482);
            this.Controls.Add(this.checkFinddark);
            this.Controls.Add(this.Bt_Correction);
            this.Controls.Add(this.Bt_LoadPoints);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Bt_SetGrayth);
            this.Controls.Add(this.textGreyth);
            this.Controls.Add(this.textCount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textOutput);
            this.Controls.Add(this.Bt_OpenImage);
            this.Controls.Add(this.imageBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "DefectPoint";
            this.Text = "FindDefectPixel";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Emgu.CV.UI.ImageBox imageBox1;
        private System.Windows.Forms.Button Bt_OpenImage;
        private System.Windows.Forms.TextBox textOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textCount;
        private System.Windows.Forms.TextBox textGreyth;
        private System.Windows.Forms.Button Bt_SetGrayth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Bt_LoadPoints;
        private System.Windows.Forms.Button Bt_Correction;
        private System.Windows.Forms.RadioButton radioArea;
        private System.Windows.Forms.RadioButton radioCloumn;
        private System.Windows.Forms.RadioButton radioNormal;
        private System.Windows.Forms.CheckBox checkFinddark;
        private System.Windows.Forms.CheckBox checkMerge;
    }
}

